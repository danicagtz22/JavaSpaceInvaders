package edu.uchicago.gerber._05dice;
import javax.swing.JComponent;
import javax.swing.JFrame;
import java.awt.*;
import java.awt.Graphics;
import java.util.Scanner;


public class P10_10 {

    public static void main(String[] args){
        JFrame frame = new JFrame();
        frame.setSize(300, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



        JComponent component = new OlympicRings();

        frame.add(component);

        frame.setVisible(true);



    }

}
