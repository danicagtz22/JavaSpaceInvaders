package edu.uchicago.gerber._05dice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Pig extends JFrame {

    private JLabel userScore;

    private JLabel PigGameLabel;
    private JLabel computerScore;
    private JLabel userCurrentScore;


    private JLabel mostRecentRoll;
    private JLabel myMostRecentRoll;

    private JButton roll;
    private JButton hold;

    private JLabel myUserScore;
    private JLabel myComputerScore;

    private JLabel myCurrentScore;




    //game outcome
    private JLabel gameOutcome;


    //computer's round output
    private JLabel computerCurrentRoundScore;
    private JLabel myComputerRoundOutput;

    private JLabel extraSpace;

    private int playerTurnScore = 0;
    private int playerTotal = 0;
    private int computerTurnScore = 0;
    private int computerTotal = 0;
    private int dice;


    public Pig()
    {
        PigGameLabel = new JLabel("Let's play a game of Pig");
        PigGameLabel.setFont(new Font("Serif", Font.BOLD, 28));
        add(PigGameLabel, BorderLayout.CENTER);
        setPreferredSize(new Dimension(300, 300));
        play();


    }

    private void play(){
        //set layout
        setLayout(new GridLayout(14, 2));

        extraSpace = new JLabel();
        add(extraSpace);

        //set user score and value
        userScore = new JLabel("                My Score: ");
        add(userScore);
        myUserScore = new JLabel();
        add(myUserScore);

        //set computer score and value
        computerScore = new JLabel("            Computer Score: ");
        add(computerScore);
        myComputerScore = new JLabel();
        add(myComputerScore);


        //set turn total for user
        userCurrentScore = new JLabel("             My Turn Total: ");
        add(userCurrentScore);
        myCurrentScore = new JLabel();
        add(myCurrentScore);

        //most recent result
        mostRecentRoll = new JLabel("               You rolled: ");
        add(mostRecentRoll);
        myMostRecentRoll = new JLabel();
        add(myMostRecentRoll);


        //computer's turn
        computerCurrentRoundScore = new JLabel("The computer score this turn: ");
        add(computerCurrentRoundScore);
        myComputerRoundOutput = new JLabel();
        add(myComputerRoundOutput);



        //add roll button
        roll = new JButton("ROLL");
        add(roll);
        ActionListener rollObj= new rollDice();
        roll.addActionListener(rollObj);

        //add hold button
        hold = new JButton("HOLD");
        add(hold);
        ActionListener holdObj = new holdDice();
        hold.addActionListener(holdObj);


        gameOutcome = new JLabel();
        add(gameOutcome);

        //call on the player to start the game

            playerRound();



    }

    private void playerRound()
    {
        myUserScore.setText(playerTotal + "");
        myComputerScore.setText(computerTotal + "");


        if (playerTotal >= 100) {
            gameOutcome.setText("You win!!");

        }
        if (computerTotal >= 100) {
            gameOutcome.setText("The computer wins!");

        }
        Random rand = new Random();

        dice = rand.nextInt(6) + 1;
        myMostRecentRoll.setText(dice + "");
        if (dice == 1) {
            System.out.println("you rolled a 1, turn is over");
            playerTurnScore = 0;
            myCurrentScore.setText(playerTurnScore + " ");


            computerRound();
        } else {
            playerTurnScore += dice;
            myCurrentScore.setText(playerTurnScore + " ");

        }
    }

    private void computerRound()
    {

        if (playerTotal >= 100) {
            gameOutcome.setText("You win!!");

        }
        if (computerTotal >= 100) {
            gameOutcome.setText("The computer wins");

        }
        Random rand = new Random();
            dice = rand.nextInt(6) + 1;
            System.out.println("dice roll " + dice);
            if (dice == 1) {
                computerTurnScore = 0;
                myComputerRoundOutput.setText("computer scored 0");
                playerRound();
            } else {
                computerTurnScore += dice;
                myComputerRoundOutput.setText(computerTurnScore + "");
                System.out.println("current run score " + computerTurnScore);
                if (computerTurnScore >= 20 || (computerTotal +
                        computerTurnScore) >= 100) {
                    computerTotal += computerTurnScore;
                    System.out.println("computer folds");
                    myComputerScore.setText(computerTotal + "");

                    computerTurnScore = 0;

                    playerRound();
                }
                else{
                    computerRound();
                }
            }
    }


    class rollDice implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            System.out.println("you decided to roll");
           playerRound();

        }
    }

    class holdDice implements ActionListener {
        public void actionPerformed(ActionEvent event) {

            System.out.println("you decided to hold");
            playerTotal += playerTurnScore;
            myUserScore.setText(playerTotal + "");
            playerTurnScore = 0;
            computerRound();
        }
    }
}
