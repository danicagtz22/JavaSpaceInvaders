package edu.uchicago.gerber._03objects;
import java.lang.Math;
import java.util.Random;

public class P8_7 {
    public static void main(String[] args)
    {

        /*the specification does not say that we need to make this interactive, so I
        will just instantiate an object with random numbers between 0 and 39*/
        //ComboLock myComboLock = new ComboLock(new Random().nextInt(40), new Random().nextInt(40), new Random().nextInt(40));
        ComboLock myComboLock = new ComboLock(36,8,1);
        myComboLock.turnRight(4);
        myComboLock.turnLeft(12);
        myComboLock.turnRight(7);
        boolean isOpen = myComboLock.open();

        System.out.println(isOpen);

    }
}


class ComboLock
{
    private int secretNumber1;
    private int secretNumber2;
    private int secretNumber3;

    private int input1;
    private int input2;
    private int input3;

    int currentNum = 0;
    int currentPosition = 0;

    ComboLock(int num1, int num2, int num3){
        this.secretNumber1 = num1;
        this.secretNumber2 = num2;
        this.secretNumber3 = num3;
        System.out.println(secretNumber1);
        System.out.println(secretNumber2);
        System.out.println(secretNumber3);
    }

    public void reset(){
        this.input1 = 0;
        this.input2 = 0;
        this.input3 = 0;
        currentNum = 0;
        currentPosition = 0;

    }


    public void turnRight(int ticks){
        if (currentPosition == 0){
            currentNum = (40 - ticks) % 40;
            System.out.println("num1 " + currentNum);
            input1 = currentNum;
            currentPosition = 1;
        } else if( currentPosition == 2 ){
            currentNum = ((currentNum - ticks) + 40) % 40;
            input3 = currentNum;
            System.out.println("num3 " + currentNum);
        }

    }
    public void turnLeft(int ticks){
        if (currentPosition == 1){
            currentNum = (currentNum + ticks) % 40;
            currentPosition = 2;
            input2 = currentNum;
            System.out.println("num2 " + currentNum);
        }
    }



    public boolean open(){
        boolean isOpen;
        if(input1 == secretNumber1 && input2 == secretNumber2 && input3 == secretNumber3){
            isOpen = true;
        }
        else{
            isOpen = false;
        }
        return isOpen;
    }





}