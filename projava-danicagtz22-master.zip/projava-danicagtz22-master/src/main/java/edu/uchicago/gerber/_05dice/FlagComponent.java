package edu.uchicago.gerber._05dice;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JComponent;

import javax.swing.*;

public class FlagComponent extends JComponent {

    public void paintComponent(Graphics g){
        drawGermanFlag(g, 10, 10, 100);
        drawHungarianFlag(g, 10, 70, 100);

    }


    void drawFlag(Graphics g, int xLeft, int yTop, int width){
        g.setColor(Color.GREEN);
        g.fillRect(xLeft, yTop, width * 5/6, width / 6);
        g.setColor(Color.WHITE);
        g.fillRect(xLeft, yTop + width / 6, width * 5 / 6, width / 6);
        g.setColor(Color.RED);
        g.fillRect(xLeft, yTop + 2 * width / 6, width * 5 / 6, width / 6);
    }

    void drawHungarianFlag(Graphics g, int xLeft, int yTop, int width){
        g.setColor(Color.RED);
        g.fillRect(xLeft, yTop, width * 5/6, width / 6);
        g.setColor(Color.WHITE);
        g.fillRect(xLeft, yTop + width / 6, width * 5 / 6, width / 6);
        g.setColor(Color.GREEN);
        g.fillRect(xLeft, yTop + 2 * width / 6, width * 5 / 6, width / 6);
    }

    void drawGermanFlag(Graphics g, int xLeft, int yTop, int width){
        g.setColor(Color.BLACK);
        g.fillRect(xLeft, yTop, width * 5/6, width / 6);
        g.setColor(Color.RED);
        g.fillRect(xLeft, yTop + width / 6, width * 5 / 6, width / 6);
        g.setColor(Color.YELLOW);
        g.fillRect(xLeft, yTop + 2 * width / 6, width * 5 / 6, width / 6);
    }



}
