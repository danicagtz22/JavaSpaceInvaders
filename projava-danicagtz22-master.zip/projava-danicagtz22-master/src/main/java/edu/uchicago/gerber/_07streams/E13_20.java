package edu.uchicago.gerber._07streams;

import java.util.*;

public class E13_20 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter a positive integer price number: ");
        int inputNumber = in.nextInt();
        paymentOptions(inputNumber);
    }

    public static void paymentOptions(int intPrice) {
        ArrayList<Integer> billOptions = new ArrayList<Integer>();
        ArrayList<String> results = new ArrayList<String>();
        //initialize the list to 4 elements of 0
        billOptions.add(0);
        billOptions.add(0);
        billOptions.add(0);
        billOptions.add(0);
        //output formatting
        System.out.println("These are the bill combinations you can give");
        System.out.println("-----------------------");
        System.out.println(" $1 | $5 | $20 | $100");
        System.out.println("-----------------------");
        makePayment(intPrice, 0, billOptions, results);
        for(String combination: results) {
            System.out.println(combination);
        }
    }

    public static void makePayment(int intPrice, int i, ArrayList<Integer> billCombinations, ArrayList<String> resultsList) {
        int sum = getSum(billCombinations);
        if (sum == intPrice) {
            //base case, we'll be adding bills until amount is reached
            resultsList.add(0, billCombinations.toString());
        } else {
            // i keeps track of the bill type
            while (i < billCombinations.size()) {
                billCombinations.set(i, billCombinations.get(i) + 1);
                if (getSum(billCombinations) <= intPrice) {
                    //recursive call adds a given bill until price is matched
                    makePayment(intPrice, i, billCombinations, resultsList);
                }
                billCombinations.set(i, billCombinations.get(i) - 1);
                ++i;
            }
        }


    }
    public static int getSum(ArrayList<Integer> combinations) {
        //initially this list is a list of 4 elements set to 0
        int sum = combinations.get(0);
        sum += 5 * combinations.get(1);
        sum += 20 * combinations.get(2);
        sum += 100 * combinations.get(3);
        return sum;
    }

}
