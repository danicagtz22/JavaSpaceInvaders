package edu.uchicago.gerber._07streams;


import java.util.Scanner;

public class E13_4 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter an integer number: ");
        int inputNumber = in.nextInt();
        System.out.println("This is the binary notation of  " + inputNumber + " : " + binaryString(inputNumber));

    }

    public static String binaryString(int n) {
        // base case, return empty string
        if(n == 0){
            return "";
        }
        // if n is even, then the last digit must be 0
        if(n % 2  == 0) // even numbers have a 0 remainder when divided by 2
        {
            //recursive call to obtain remaining digits, append a "0" for each call that falls here
            return binaryString(n/2) + '0';
        }

        //if the number is odd, a "1" is added to the string to be returned
        else{
            return binaryString(n/2) + '1';
        }
    }
}
