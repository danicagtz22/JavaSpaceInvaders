package edu.uchicago.gerber._07streams;

import java.util.Scanner;

public class YodaSpeakRecursive {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter a phrase : ");
        String inputPhrase = in.nextLine();
        System.out.println("Yodaspeak for that is:  " + yodaspeakRecursive(inputPhrase));

    }

    public static String yodaspeakRecursive(String s){
       //base case
        if (s.isEmpty()) {
            return s;
        }
        //the string will be split into two each recursive call until there are no more 'otherWords' left, then
        //this will return the string in reverse order
        String[] stringArray = s.split(" ", 2);
        String firstWord = stringArray[0];
        String otherWords;
        if (stringArray.length == 2)
            otherWords = stringArray[1];
        else
            otherWords = "";
        //each of the words in the string gets to be the 'firstWord' until there are no more words left
        return yodaspeakRecursive(otherWords) + firstWord + " ";
    }
}
