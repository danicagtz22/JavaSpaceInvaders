package edu.uchicago.gerber._07streams;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;


/* read all words in a file and group them by the first letter (in lowercase). Print the average word length for each
initial letter. Use collect and Collectors.groupingBy
 */
public class E19_16 {
    public static void main(String args[]) throws IOException {

        Stream<String> lines = Files.lines(Paths.get("warandpeace.txt"));
           Map<Object,Double> avgWordLength = lines
                .flatMap(line-> Arrays.stream(line.split("[^a-zA-Z]")))
                        .filter(s -> s.length() > 0)
                        .map(s -> s.toLowerCase())
                        .collect(Collectors.groupingBy(
                                s -> s.substring(0,1),
                                Collectors.averagingDouble(String::length)));


        //traverse through map and print average length for each letter initial
        for(Map.Entry<Object,Double> ele : avgWordLength.entrySet())
        {
            System.out.print("\n" + ele.getKey() + " letter words : " + ele.getValue() );


        }
    }

}
