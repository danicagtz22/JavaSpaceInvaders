package edu.uchicago.gerber._02arrays;
import java.util.Random;
import java.util.Arrays;


public class E6_12 {
    //Write a program that generates a sequence of 20 random values between 0 and 99 in an array, prints the sequence,
    // sorts it and prints the sorted sequence. Use the sort method from the standard Java library
    public static void main(String []args){


        // define the range of values
        int max = 99;
        int min = 0;
        int range = max - min + 1;
        //create an array of 20 elements.
        int[] ar1 = new int[20];
        System.out.println("\nElements of array from 0 to 99: ");
        for(int i = 0; i <  ar1.length; i++) {
            // to get the random elements in the range from 0-99 we multiply Math.random() by our range (which is inclusive) (a random decimal value from 0-1 by our range)
            ar1[i] = (int)(Math.random() * range);
            System.out.print(ar1[i] + "  ");
        }
        //using sort() method of the Arrays class
        Arrays.sort(ar1);
        System.out.println("\nElements of array sorted in ascending order: ");
        //prints the sorted array using a for loop
        for (int i = 0; i < ar1.length; i++)
        {
            System.out.print(ar1[i] + "  ");
        }

    }




}


