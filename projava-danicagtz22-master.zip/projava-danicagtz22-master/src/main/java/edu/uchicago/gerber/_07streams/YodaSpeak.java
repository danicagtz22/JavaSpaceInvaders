package edu.uchicago.gerber._07streams;

import java.util.Scanner;

public class YodaSpeak {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter a phrase : ");
        String inputPhrase = in.nextLine();
        System.out.println("Yodaspeak for that is:  " + yodaspeak(inputPhrase));

    }

    public static String yodaspeak(String s){
        // create an array with all the words by splitting them using the spaces
        String stringArray[] = s.split(" ");
        String translation = "";
        //reverse the order of the words by creating a new string with the words in reverse order
        for (int i = stringArray.length - 1; i >= 0; i--)
        {
            translation += stringArray[i] + " ";
        }
        //return reversed string
        return translation;
    }
}
