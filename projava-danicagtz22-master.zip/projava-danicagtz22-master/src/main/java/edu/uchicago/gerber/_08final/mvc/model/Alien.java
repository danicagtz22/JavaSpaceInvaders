package edu.uchicago.gerber._08final.mvc.model;

import edu.uchicago.gerber._08final.mvc.controller.Game;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Alien extends Sprite {

   private boolean moveRight = true;
   private int speed;

   private boolean flap = true;
   private Point[] pntCsArms;

    private Point[] mPntCs;
    public Alien(int x, int y, int speed){
        this(x,y);
        this.speed = speed;
    }
    public Alien(int x, int y) {


       // Point position = new Point(this.x, this.y);
        setOrientation(270);
        setRadius(25);
        setTeam(Team.FOE);
        setCenter(new Point(x,y));

        //Cartesians that define the shape of a basic alien
        List<Point> pntCs = new ArrayList<>();
        pntCs.add(new Point(0,0));
        pntCs.add(new Point(2,0));
        pntCs.add(new Point(2,1));
        pntCs.add(new Point(1,1));
        pntCs.add(new Point(1,0));
        pntCs.add(new Point(2,0));
        pntCs.add(new Point(0,0));

        pntCs.add(new Point(0,2));
        pntCs.add(new Point(1,2));
        pntCs.add(new Point(1,3));
        pntCs.add(new Point(2,3));
        pntCs.add(new Point(2,4));
        pntCs.add(new Point(3,4));
        pntCs.add(new Point(3,3));
        pntCs.add(new Point(2, 3));
        pntCs.add(new Point(2,2));
        pntCs.add(new Point(3, 2));
        pntCs.add(new Point(3,1));
        pntCs.add(new Point(4, 1));
        pntCs.add(new Point(4,0));
        pntCs.add(new Point(5, 0));
        //bottom right
        pntCs.add(new Point(5, 0));
        pntCs.add(new Point(5,-3));
        pntCs.add(new Point(4, -3));
        pntCs.add(new Point(4,-1));
        pntCs.add(new Point(3, -1));
        pntCs.add(new Point(3,-3));
        pntCs.add(new Point(2, -3));
        pntCs.add(new Point(2,-4));
        pntCs.add(new Point(1,-4));
        pntCs.add(new Point(1,-3));
        pntCs.add(new Point(2,-3));
        pntCs.add(new Point(2,-2));
        pntCs.add(new Point(1,-2));
        pntCs.add(new Point(0,-2));
        //bottom left quadrant
        pntCs.add(new Point(-2,-2));
        pntCs.add(new Point(-2,-3));
        pntCs.add(new Point(-1,-3));
        pntCs.add(new Point(-1,-4));
        pntCs.add(new Point(-2,-4));
        pntCs.add(new Point(-2, -3));
        pntCs.add(new Point(-3,-3));
        pntCs.add(new Point(-3, -1));
        pntCs.add(new Point(-4,-1));
        pntCs.add(new Point(-4, -3));
        pntCs.add(new Point(-5,-3));
        pntCs.add(new Point(-5, 0));
        //top left quadrant
        pntCs.add(new Point(-5, 0));
        pntCs.add(new Point(-4,0));
        pntCs.add(new Point(-4, 1));
        pntCs.add(new Point(-3,1));
        pntCs.add(new Point(-3, 2));
        pntCs.add(new Point(-2,2));
        pntCs.add(new Point(-2, 3));
        pntCs.add(new Point(-3,3));
        pntCs.add(new Point(-3,4));
        pntCs.add(new Point(-2,4));
        pntCs.add(new Point(-2,3));
        pntCs.add(new Point(-1,3));
        pntCs.add(new Point(-1,2));
        pntCs.add(new Point(0,2));

        pntCs.add(new Point(0,0));
        pntCs.add(new Point(-2,0));
        pntCs.add(new Point(-2,1));
        pntCs.add(new Point(-1,1));
        pntCs.add(new Point(-1,0));


        mPntCs = pntCs.stream()
                .toArray(Point[]::new);

        setCartesians(pntCs);
        setColor(Color.GREEN);

        List<Point> pntCsFlap = new ArrayList<>();
        pntCsFlap.add(new Point(0,0));
        pntCsFlap.add(new Point(2,0));
        pntCsFlap.add(new Point(2,1));
        pntCsFlap.add(new Point(1,1));
        pntCsFlap.add(new Point(1,0));
        pntCsFlap.add(new Point(2,0));
        pntCsFlap.add(new Point(0,0));

        pntCsFlap.add(new Point(0,2));
        pntCsFlap.add(new Point(1,2));
        pntCsFlap.add(new Point(1,3));
        pntCsFlap.add(new Point(2,3));
        pntCsFlap.add(new Point(2,4));
        pntCsFlap.add(new Point(3,4));
        pntCsFlap.add(new Point(3,3));
        pntCsFlap.add(new Point(2, 3));
        pntCsFlap.add(new Point(2,2));
        pntCsFlap.add(new Point(3, 2));
        pntCsFlap.add(new Point(3,1));
        pntCsFlap.add(new Point(4, 1));
        pntCsFlap.add(new Point(4,5));
        pntCsFlap.add(new Point(5, 5));
        pntCsFlap.add(new Point(5, 0));
        //bottom right
        pntCsFlap.add(new Point(5, 0));
        pntCsFlap.add(new Point(5,-1));
        pntCsFlap.add(new Point(4,-1));
        pntCsFlap.add(new Point(3, -1));
        pntCsFlap.add(new Point(3,-3));
        pntCsFlap.add(new Point(2, -3));
        pntCsFlap.add(new Point(2,-4));
        pntCsFlap.add(new Point(1,-4));
        pntCsFlap.add(new Point(1,-3));
        pntCsFlap.add(new Point(2,-3));
        pntCsFlap.add(new Point(2,-2));
        pntCsFlap.add(new Point(1,-2));
        pntCsFlap.add(new Point(0,-2));
        //bottom left quadrant
        pntCsFlap.add(new Point(-2,-2));
        pntCsFlap.add(new Point(-2,-3));
        pntCsFlap.add(new Point(-1,-3));
        pntCsFlap.add(new Point(-1,-4));
        pntCsFlap.add(new Point(-2,-4));
        pntCsFlap.add(new Point(-2, -3));
        pntCsFlap.add(new Point(-3,-3));
        pntCsFlap.add(new Point(-3, -1));
        pntCsFlap.add(new Point(-4,-1));
        pntCsFlap.add(new Point(-5, -1));
        pntCsFlap.add(new Point(-5,0));
        //top left quadrant
        pntCsFlap.add(new Point(-5, 0));
        pntCsFlap.add(new Point(-5, 5));
        pntCsFlap.add(new Point(-4, 5));
        pntCsFlap.add(new Point(-4,1));
        pntCsFlap.add(new Point(-3,1));
        pntCsFlap.add(new Point(-3, 2));
        pntCsFlap.add(new Point(-2,2));
        pntCsFlap.add(new Point(-2, 3));
        pntCsFlap.add(new Point(-3,3));
        pntCsFlap.add(new Point(-3,4));
        pntCsFlap.add(new Point(-2,4));
        pntCsFlap.add(new Point(-2,3));
        pntCsFlap.add(new Point(-1,3));
        pntCsFlap.add(new Point(-1,2));
        pntCsFlap.add(new Point(0,2));

        pntCsFlap.add(new Point(0,0));
        pntCsFlap.add(new Point(-2,0));
        pntCsFlap.add(new Point(-2,1));
        pntCsFlap.add(new Point(-1,1));
        pntCsFlap.add(new Point(-1,0));


        pntCsArms = pntCsFlap.stream()
                    .toArray(Point[]::new);



    }

    public void move(){

        if (getExpiry() > 0) expire();

        //move right
        if (moveRight) {
            getCenter().move(getCenter().x + speed, getCenter().y);
        } else {
            getCenter().move(getCenter().x - speed, getCenter().y);
        }

      }

      public void flap(boolean flappy){
        if(flappy){

                setCartesians(pntCsArms);
            }else{
                setCartesians(mPntCs);
            }

      }
      public void rotate(){
        moveRight = !moveRight;
        getCenter().move(getCenter().x, getCenter().y + 15);

      }


}
