package edu.uchicago.gerber._04interfaces;

import java.util.Scanner;

public class P9_1 {

    public static void main(String[] args) {



        //create a new clock
        Clock myClock= new Clock();

        //print the time by calling out separate methods
        System.out.println(myClock.getHours() + " : " + myClock.getMinutes());


        //take user input
        System.out.print("how many hours should we offset clock by? enter an integer number");
        Scanner scanIn = new Scanner(System.in);
        int day = scanIn.nextInt();
        //create a WorldClock instance
        WorldClock myWorldClock = new WorldClock(day);

        //use the getTime method to get the current time of the world clock object. Thus avoiding to override getTime
        //Only the getHours method had to be overwritten as hour is the only unit of time that is affected in most cases
        System.out.println(myWorldClock.getHours() + " : " + myWorldClock.getMinutes());
        System.out.println("New Time " + myWorldClock.getTime());

    }

}

class Clock {

    private int minutes;

    private  int hours;
    public Clock(){

    }

    public int getMinutes() {

        String timeString = new java.util.Date().toString();

        return Integer.parseInt(timeString.substring(14, 16));
    }

    public int getHours() {

        String timeString = new java.util.Date().toString();

        return Integer.parseInt(timeString.substring(11, 13));
    }

    public String getTime() {
        String time = getHours() + ":" + getMinutes();
        return time;

    }


}

class WorldClock extends Clock{


    private int hoursOffset;

    // constructor that accepts a time offset
    public WorldClock(int hoursOffset) {

        this.hoursOffset = hoursOffset;

    }

    //getHour method will be overwritten
    public int getHours() {

        //we call super to get the hours from the superclass object and then add the hours offset
        int newHour = super.getHours() + hoursOffset;

        if (newHour > 23) {
            //A day has 24 hrs, so we want to keep all operations in the range 0-23
            newHour = ((super.getHours() + hoursOffset) + 24 ) % 24;

    }

        if (newHour < 0) {
        //for those time zones that are behind we add 24
            newHour = 24 + newHour;

        }

        return newHour;

    }

}