package edu.uchicago.gerber._04interfaces;

import java.util.Scanner;

public class P9_6 {

    public static void main(String[] args) {


        //create random appointment objects array
        Appointment[] myAppts = new Appointment[4];
        myAppts[0] = new Onetime(12, 6, 2022, "dentist");
        myAppts[1] = new Monthly(14, 7, 2022, "nails");
        myAppts[2] = new Daily(14, 7, 2022, "management check-in");
        myAppts[3] = new Monthly(12, 6, 2022, "physical exam");

        //take input from user
        Scanner scanIn = new Scanner(System.in);


        //get a date
        System.out.print("Let's find appointments! Enter day: ");
        int day = scanIn.nextInt();

        System.out.print("Enter month: ");
        int month = scanIn.nextInt();

        System.out.print("Enter year: ");
        int year = scanIn.nextInt();

        boolean any = false;
        //iterate through array
        for(int i = 0; i<myAppts.length; i++){

         if (myAppts[i].occursOn(day, month, year))
            {
             any = true;
             System.out.println(myAppts[i].getDescription());

            }
        }

        if(!any){
            System.out.println("No appointments on this date");

        }

    }

}

class Appointment {

  private String description;
  private int year;
  private int month;
  private int day;


  public Appointment(int day, int month, int year, String description){
    this.day = day;
    this.month = month;
    this.year = year;
    this.description = description;
  }

  public String getDescription(){return this.description;}

  public int getYear() {return this.year;}
  public int getMonth() {return this.month;}
  public int getDay() {return this.day;}




  public boolean occursOn(int day, int month, int year){
      if(day == this.getDay() && month == this.getMonth() && year == this.getYear()){
          return true;
      }
      else{
          return false;
      }
  }

}

class Onetime extends Appointment{


    //one time appointments don't need an additional method because they only happen once and there's no need
    // to overwrite the occursOn method from the superclass
    public Onetime(int day, int month, int year, String description){
        super(day, month, year, description);
    }

}

class Daily extends Appointment {

    public Daily(int day, int month, int year, String description) {
        super(day, month, year, description);
    }

    public boolean occursOn(int day, int month, int year) {

        //it will occur daily after the startup day
        //we need to check date is after this startup day
        //conditional reference taken from chegg.com
        if (year > this.getYear()) {
            return true;
        }
        if (year == this.getYear()) {
            if (month > this.getMonth()) {
                return true;
            }
            if (month == this.getMonth()) {
                if (day >= this.getDay()) {
                    return true;
                }
            }
        }
        return false;
    }
}
    class Monthly extends Appointment {

        public Monthly(int day, int month, int year, String description) {
            super(day, month, year, description);

        }



    public boolean occursOn(int day, int month, int year) {

        if (year == this.getYear() && month >= this.getMonth() && day == this.getDay()) {
            return true;
        } else if (year > this.getYear() && day == this.getDay()) {
            return true;
        } else {
            return false;
        }

    }

}
