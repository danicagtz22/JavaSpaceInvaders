package edu.uchicago.gerber._08final.mvc.model;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Bomb extends Sprite{
    private boolean collision;

    public Bomb(Alien alien) {



        setTeam(Team.FOE);

        //a bomb expires after 33 frames. set to one more than frame expiration
        setExpiry(33);
        setRadius(6);


        //everything is relative to the alien ship that dropped the bomb
        setCenter(alien.getCenter());

        //set the bomb orientation to the alien (ship) orientation
        setOrientation(alien.getOrientation());

        final double FIRE_POWER = 15.0;
        setDeltaX(alien.getDeltaX() +
                Math.cos(Math.toRadians(alien.getOrientation())) * FIRE_POWER);
        setDeltaY(alien.getDeltaY() -
                Math.sin(Math.toRadians(alien.getOrientation())) * FIRE_POWER);


        //defined the points on a cartesian grid
        List<Point> pntCs = new ArrayList<>();
        pntCs.add(new Point(5, 5));
        pntCs.add(new Point(4,0));
        pntCs.add(new Point(5, -5));
        pntCs.add(new Point(0,-4));
        pntCs.add(new Point(-5, -5));
        pntCs.add(new Point(-4,0));
        pntCs.add(new Point(-5, 5));
        pntCs.add(new Point(0,4));

        setCartesians(pntCs);



    }
    public void setCollision(){
        this.collision = true;
    }
    public boolean getCollision(){
        return this.collision;

    }
    @Override
    public void move() {
        super.move();
        if(getCollision()){
            CommandCenter.getInstance().getOpsQueue().enqueue(new FalconDeath(this), GameOp.Action.ADD);
        }
    }


}
