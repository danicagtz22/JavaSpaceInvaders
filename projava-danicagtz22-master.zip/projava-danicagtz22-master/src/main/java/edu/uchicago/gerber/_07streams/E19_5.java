package edu.uchicago.gerber._07streams;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

//write a method that turns a Stream<T> into a comma separated list of its first n elements
public class E19_5 {
    public static void main(String[] args) {

        //testing out a String list
        List<String> list = new ArrayList<>();
        list.add("Michigan");
        list.add("Superior");
        list.add("Erie");
        list.add("Ontario");
        list.add("Heron");

        //testing out an integer list
        List<Integer> listInt = new ArrayList<>();
        listInt.add(1);
        listInt.add(2);
        listInt.add(3);
        listInt.add(4);
        listInt.add(5);
        String res = toString(listInt.stream(), 4);

        System.out.println(res);
    }

    //method that converts a generic stream into a comma separated list of its first n elements
    public static <T> String toString(Stream<T> stream, int n){
            String result =     stream
                                .limit(n)
                                .map( elem -> "" + elem)
                                .collect(Collectors.joining(", "));

            return result;
    }
}
