package edu.uchicago.gerber._08final.mvc.model;



import edu.uchicago.gerber._08final.mvc.controller.Game;
import edu.uchicago.gerber._08final.mvc.controller.Sound;
import lombok.Data;

import java.awt.*;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

//the lombok @Data gives us automatic getters and setters on all members
@Data
public class CommandCenter {

	private  int numFalcons;
	private  int level;
	private  long score;
	private  boolean paused;

	//the falcon is located in the movFriends list, but since we use this reference a lot, we keep track of it in a
	//separate reference. Use final to ensure that the falcon ref always points to the single falcon object on heap
	//Lombok will not provide setter methods on final members
	private final Falcon falcon  = new Falcon();

	//lists containing our movables
	private final List<Movable> movDebris = new LinkedList<>();
	private final List<Movable> movFriends = new LinkedList<>();
	private final List<Movable> movFoes = new LinkedList<>();
	private final List<Movable> movFloaters = new LinkedList<>();

	private final GameOpsQueue opsQueue = new GameOpsQueue();

	//singleton
	private static CommandCenter instance = null;

	// Constructor made private
	private CommandCenter() {}

    //this class maintains game state - make this a singleton.
	public static CommandCenter getInstance(){
		if (instance == null){
			instance = new CommandCenter();
		}
		return instance;
	}


	public void addPointsToScore(int points){
		this.score += points;
	}


	public void initGame(){
		clearAll();
		setLevel(1);
		setScore(0);
		setPaused(false);
		//set to one greater than number of falcons lives in your game as initFalconAndDecrementNum() also decrements
		setNumFalcons(4);
		initFalconAndDecrementFalconNum();
		createBoulderShields();
		createNewAliens(getLevel());
		opsQueue.enqueue(falcon, GameOp.Action.ADD);

	}

	//the level determines the speed of the aliens
	public void createNewAliens(int speed) {
		int ax = 80;
		int ay = 80;
		for(int i=0; i < 50; i++){
			Alien newAlien = new Alien(ax, ay, speed +2);
			opsQueue.enqueue(newAlien, GameOp.Action.ADD);
			ax += 80;
			if ((i + 1) % 10 == 0){
				ax=80;
				ay += 50;
			}
		}
	}

	public void createBoulderShields() {
			BoulderShield boulder1 = new BoulderShield(Game.DIM.width/4, Game.DIM.height - 200);
			BoulderShield boulder2 = new BoulderShield(Game.DIM.width/2, Game.DIM.height - 200);
			BoulderShield boulder3 = new BoulderShield(Game.DIM.width - 275, Game.DIM.height - 200);


		opsQueue.enqueue(boulder1, GameOp.Action.ADD);
		opsQueue.enqueue(boulder2, GameOp.Action.ADD);
		opsQueue.enqueue(boulder3, GameOp.Action.ADD);

	}

	public void initFalconAndDecrementFalconNum(){
		setNumFalcons(getNumFalcons() - 1);
		if (isGameOver()) return;
		Sound.playSound("shipspawn.wav");
		falcon.setFade(Falcon.FADE_INITIAL_VALUE);

		//put falcon at the bottom of the game-space
		falcon.setCenter(new Point(Game.DIM.width / 2,  Game.DIM.height - 100));
		falcon.setOrientation(270);
		falcon.setDeltaX(0);
		falcon.setDeltaY(0);
	}

	private void clearAll(){
		movDebris.clear();
		movFriends.clear();
		movFoes.clear();
		movFloaters.clear();
	}

	public boolean isGameOver() {
		long alienCount = movFoes.stream()
				.filter(m -> m instanceof Alien)
				.filter(m -> m.getCenter().y > Game.DIM.height -80)
				.count();


		if(getNumFalcons() <= 0 || alienCount > 0 ){
			return true;
		}

		return false;
	}

	public static void  generateDebris(Sprite sprite){

		for (int nC = 0; nC < 10; nC++) {
			Point center = sprite.getCenter();
			Point other = new Point(
					center.x + sprite.somePosNegValue(50),
					center.y + sprite.somePosNegValue(50));

			Point[] twoPoints = {center, other};

			CommandCenter.getInstance().getOpsQueue().add(new GameOp(new Explosion(twoPoints, sprite), GameOp.Action.ADD));



		}



	}



}
