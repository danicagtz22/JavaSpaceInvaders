package edu.uchicago.gerber._08final.mvc.model;


import lombok.Data;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;
import java.awt.Point;

public class BrickBoulderShield extends Sprite {

    private final int BRICK_IMAGE = 0;

    //The size of this brick is always square!
    //we use upperLeftCorner because that is the origin when drawing graphics in Java
    public BrickBoulderShield(Point upperLeftCorner, int size) {

        setTeam(Team.FRIEND);

        setCenter(new Point(upperLeftCorner.x + size/2, upperLeftCorner.y + size/2));

        setRadius(size/2);

        Map<Integer, BufferedImage> rasterMap = new HashMap<>();

        rasterMap.put(BRICK_IMAGE, loadGraphic("/imgs/White_Brick.png") );

        setRasterMap(rasterMap);


    }

    @Override
    public void draw(Graphics g) {
        renderRaster((Graphics2D) g, getRasterMap().get(BRICK_IMAGE));

    }

} //end class
