package edu.uchicago.gerber._02arrays;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;


public class test {
    //some code referenced from https://explained.blog/programming/program-to-print-vertical-bar-chart/
    public static void main(String[] args) {


        int[][] values = new int[5][7];
        int val = 1;
        for (int[] row : values) {
            Arrays.fill(row, val);
        }
        for (int i=0; i < 5; i+=5-1) {
            for (int j=0; j < 7; j++) {
                values[i][j] = 0;
                System.out.print(values[i][j]+" ");
            }
            System.out.println();
        }
        for(int i=0;i<5;i++){
            for(int j=0;j<7;j++) {
                System.out.print(values[i][j]+" ");
            }
            System.out.println();
        }
    }

}