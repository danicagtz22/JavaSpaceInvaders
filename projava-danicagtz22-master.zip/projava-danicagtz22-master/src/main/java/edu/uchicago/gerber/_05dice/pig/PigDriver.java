package edu.uchicago.gerber._05dice.pig;

import edu.uchicago.gerber._05dice.Pig;
import edu.uchicago.gerber._05dice.RestaurantBillMaker;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class PigDriver {

    public static void main(String[] args) {
        //pig game here
            Pig pig = new Pig();
            pig.setDefaultCloseOperation(EXIT_ON_CLOSE);
            pig.setSize(800,800);
            pig.setVisible(true);

    }
}
