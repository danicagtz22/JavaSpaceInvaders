package edu.uchicago.gerber._03objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class P8_19 {
    public static void main(String[] args)
    {
        // Code referenced https://www.youtube.com/watch?v=Rj1HJNNpuPs&ab_channel=RichardWhite
        Scanner in = new Scanner(System.in);
        System.out.println("What's the x-position of the cannonball? Please enter a number");
        String initialXPosition = in.nextLine();
        Cannonball myCannonball = new Cannonball(Double.parseDouble(initialXPosition));
        // Use Scanner object to get user input
        System.out.println("Enter a starting angle in numeric form to launch cannonball");
        String angle = in.nextLine();
        System.out.println("You entered  " + angle);
        System.out.println("Enter an initial velocity to launch cannonball");
        String initialVelocity = in.nextLine();
        System.out.println("You entered  " + initialVelocity);

       myCannonball.shoot(Double.parseDouble(angle),Double.parseDouble(initialVelocity));




    }
}
class Cannonball{

    private double xPosition = 0;
    private double yPosition = 0;
    private double xVelocity = 0;
    private double yVelocity= 0;



    public Cannonball(double xPosition){
    this.xPosition = xPosition;
    }

    public void move(double sec){
        double xDistance = xVelocity * sec;
        double yDistance = yVelocity * sec + .5*(-9.81 * sec * sec);

        this.xPosition = xPosition + xDistance;
        this.yPosition = yPosition + yDistance;
        this.yVelocity = yVelocity + (-9.81 * sec);

    }

    public void shoot(double angle, double velocity){


        this.xVelocity = velocity * Math.cos(Math.toRadians(angle));

        this.yVelocity = velocity * Math.sin(Math.toRadians(angle));

        move(.1);
        System.out.println("Ball is at position: ");
        while (yPosition > 0)
        {
            move(.1);
            System.out.println("X: "+ getxPosition() + ", " + " Y: " + getyPosition());
        }

    }

    public double getxPosition(){
        return this.xPosition;
    }

    public double getyPosition(){
        return this.yPosition;
    }

}

