package edu.uchicago.gerber._06design.E0_4;

import java.util.ArrayList;


public class VendingMachine {

    private ArrayList<Product> inventory = new ArrayList<Product>();



    private ArrayList<Coins> moneyInCoins= new ArrayList<Coins>();

    public int quarters;

    public int dimes;

    public int nickels;

    public int pennies;


    //get inventory
    public ArrayList<Product> getInventory(){
        return this.inventory;
    }



    public boolean inInventoryAlready(String prodName){
        boolean added = false;
        for(Product p : inventory){
            if(prodName.equals(p.getDescription())){
                added = true;
            }
        }
        return added;
    }

    public void restock(String prodName, int quantity){
        for (Product p : inventory){
            if(p.getDescription().equals(prodName)){
                p.addProduct(quantity);
            }
        }
    }
    public void removeMoney(ArrayList<Coins> coinsToRemove){
        for(Coins c : coinsToRemove){
            this.moneyInCoins.remove(c);

            if (c.getValue() == 0.25){
                this.quarters -= 1;
            }
            if (c.getValue() == 0.10){
                this.dimes -= 1;
            }
            if (c.getValue() == 0.05){
                this.nickels -= 1;
            }
            if (c.getValue() == 0.01){
                this.pennies -= 1;
            }
        }

    }

    //get money in coins
    public double getMoneyInCoins(){
        double totalAmount= 0;
        for (Coins c : this.moneyInCoins){
            totalAmount += c.getValue();
        }
        return totalAmount;
    }


    public double getMoneyInCoins(ArrayList<Coins> insertedCoins){
        double totalAmount = 0;
        for (Coins c : insertedCoins){
            totalAmount += c.getValue();
        }
        return totalAmount;
    }


    public void addProduct(Product product){
        this.inventory.add(product);
    }

    //add coins
    public void addCoin(Coins c){
        moneyInCoins.add(c);

        if (c.getValue() == 0.25){
            this.quarters += 1;
        }
        if (c.getValue() == 0.10){
            this.dimes += 1;
        }
        if (c.getValue() == 0.05){
            this.nickels += 1;
        }
        if (c.getValue() == 0.01){
            this.pennies += 1;
        }
    }


    //Buy product
    public double buyProduct(double productPrice, ArrayList<Coins> amountInserted, Product product){

        double inputAmount = getMoneyInCoins(amountInserted);

        double change;
        if (inputAmount > productPrice){
            //don't forget to remove product from inventory
            removeProduct(product);

            change = -1;

        }else if(inputAmount == productPrice){
            //don't forget to remove product from inventory
            removeProduct(product);
            change = 0;
        }
        else {
            //return insufficient funds
            removeMoney(amountInserted);
            change = inputAmount;
        }
        return change;
    }

    // remove product
    private void removeProduct(Product p){
       int index =  inventory.indexOf(p);
       Product product = inventory.get(index);
       product.removeProduct(1);
    }







}
