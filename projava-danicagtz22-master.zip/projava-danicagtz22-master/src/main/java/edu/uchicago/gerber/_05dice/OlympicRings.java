package edu.uchicago.gerber._05dice;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JComponent;


public class OlympicRings extends JComponent {


    public void paintComponent(Graphics g){
        drawOlympicRings(g);
        drawRing(g, 100, 100, 100, 100, 100, 100);
    }


    //To specify a color we use the RBG system where we state the amount of red, blue and green between 0-255 for
    //each

    void drawRing(Graphics g, int xLeft, int yTop, int size, int red, int blue, int green){
        g.setColor(new Color(red, blue, green));
        g.drawOval(xLeft, yTop, size, size);
    }

    void drawOlympicRings(Graphics g){

        drawRing(g,30, 30, 30, 0, 0, 255);

        drawRing(g,50, 45, 30, 255, 255, 0 );

        drawRing(g, 70, 30, 30, 0,0, 0);

        drawRing(g,90, 45, 30, 0, 255, 0);

        drawRing(g,110, 30, 30, 255, 0, 0);
    }





}
