package edu.uchicago.gerber._06design.E0_4;

import java.util.ArrayList;
import java.util.Scanner;

public class P12_1 {
    public static void main(String[] args) {

        // get input from user by creating a scanner instance
        Scanner input = new Scanner(System.in);
        char ch;
        VendingMachine vendingMachine = new VendingMachine();
        while (true) {

            // show the menu of options to the user
            System.out.println("S)how products B)uy A)dd product R)emove coins Q)uit");
            // get user option
            ch = input.nextLine().charAt(0);
            // ADD
            if (ch == 'A' || ch == 'a') { //add product
                // determine the product
                System.out.println("Description: ");
                String productNameDesc = input.nextLine();

                //if the product is already in the vending machine, increase its quantity, otherwise
                // create a new product object and add to inventory

                if (vendingMachine.inInventoryAlready(productNameDesc)) {

                    //set new quantity of product by asking user for input
                    System.out.println("Quantity:");
                    int quantity = input.nextInt();
                    vendingMachine.restock(productNameDesc, quantity);
                } else {

                    // ask for product price
                    System.out.println("Price: ");
                    double price = input.nextDouble();
                    // ask for product quantity
                    System.out.println("Quantity:");
                    int quantity = input.nextInt();
                    input.nextLine();
                    // create a new product object with the inputs given
                    Product newProduct = new Product(productNameDesc, price, quantity);
                    // add product to vending machine
                    vendingMachine.addProduct(newProduct);
                }
            }
            //SHOW
            //Show customer the product inventory
            else if (ch == 'S' || ch == 's') {
                // get product list and print it
                ArrayList<Product> list = vendingMachine.getInventory();
                if (list == null) {
                    System.out.println("List is empty");
                } else {
                    for (Product product : list) {
                        System.out.println(String.format("%s : $ %s", product.getDescription(), product.getPrice()));
                    }
                }
            }
            //BUY
            //if the user wants to buy a product, we show inventory with prices, get them to select the product, add coins
            // and a) get product if sufficient money was put in || b) get insufficient funds back
            else if (ch == 'B' || ch == 'b') { // user wants to buy a product
                // get product list and print it with the number options on the side for user selection.
                ArrayList<Product> list = vendingMachine.getInventory();
                System.out.println("Select a number option from the list");
                for (int i = 0; i < list.size(); i++) {
                    System.out.print((i + 1) + ") ");
                    System.out.println(String.format("%s : %s", list.get(i).getDescription(), list.get(i).getPrice()));
                }
                // get user product selection
                int option = input.nextInt();
                input.nextLine();
                // validate user input selection. If number not in list, throw invalid option error
                if (option > list.size() || option < 1) {
                    System.err.println("invalid option! select a product number from the list");
                } else {
                    //get the price of the product
                    double selectedProductPrice = vendingMachine.getInventory().get(option - 1).getPrice();
                    // purchase the product
                    System.out.println("Insert coins by selecting their type from the following list. press x when done.");
                    System.out.println("A) nickel = $ 0.05");
                    System.out.println("B) dime = $ 0.1");
                    System.out.println("C) quarter = $0.25");
                    System.out.println("D) penny = $0.01");

                    ArrayList<Coins> amountInserted = new ArrayList<Coins>();
                    // get coin from customer
                    ch = input.nextLine().charAt(0);
                    do {
                        ch = input.nextLine().charAt(0);
                        // check the coin
                        if (ch == 'A' || ch == 'a') {

                            // create a coin object of type nickel
                            Coins coin = new Coins("nickel", 0.05);
                            // add coin to vending machine and keep track of its quantity
                            amountInserted.add(coin);
                            vendingMachine.addCoin(coin);
                        } else if (ch == 'B' || ch == 'b') {
                            // create a coin object of type dime
                            Coins coin = new Coins("dime", 0.1);
                            // add coin to vending machine and keep track of its quantity
                            amountInserted.add(coin);
                            vendingMachine.addCoin(coin);

                        } else if (ch == 'C' || ch == 'c') {
                            // create a coin object of type quarter
                            Coins coin = new Coins("quarter", 0.25);
                            // add coin to vending machine and keep track of its quantity
                            amountInserted.add(coin);
                            vendingMachine.addCoin(coin);
                        } else if (ch == 'D' || ch == 'd') {
                            // create a coin object of type penny
                            Coins coin = new Coins("penny", 0.01);
                            // add coin to vending machine and keep track of its quantity
                            amountInserted.add(coin);
                            vendingMachine.addCoin(coin);
                        } else if(ch =='x'){
                            System.out.println("You are done inserting coins");
                        }else {
                            System.err.println("Select a valid option");
                        }
                    }while(ch != 'x');


                    double changeBack = vendingMachine.buyProduct(selectedProductPrice, amountInserted, vendingMachine.getInventory().get(option - 1));

                    if (changeBack == -1) {
                        System.out.println("You've inserted too much money and we don't give change back :( retrieve product!");
                    } else if (changeBack == 0) {
                        System.out.println("Retrieve product!");
                    } else {
                        System.out.println(String.format("Insufficient funds. Here's your money back: %s", vendingMachine.getMoneyInCoins(amountInserted)));
                    }
                }
            }
            //REMOVE MONEY
            else if (ch == 'R' || ch == 'r') {
                // Report how much money is available in the machine, so user knows how much to remove
                System.out.println(String.format("This machine has $ %s inside", vendingMachine.getMoneyInCoins()));

                System.out.println(String.format("Quarters: %s, Dimes: %s, Nickels: %s, Pennies: %s",
                        vendingMachine.quarters,
                        vendingMachine.dimes,
                        vendingMachine.nickels,
                        vendingMachine.pennies));
                System.out.println("How much do you wish to remove?");
                double amountToRemove = input.nextDouble();
                if (amountToRemove > vendingMachine.getMoneyInCoins()) {
                    System.out.println(String.format("You cannot remove more than $ %s !", vendingMachine.getMoneyInCoins()));
                } else {
                    System.out.println("choose the coins you wish to remove. Enter 'x' when done");
                    System.out.println("A) nickel = $ 0.05");
                    System.out.println("B) dime = $ 0.1");
                    System.out.println("C) quarter = $0.25");
                    System.out.println("D) penny = $0.01");

                    ArrayList<Coins> coinsRemoved = new ArrayList<Coins>();
                    // get coin from customer
                    ch = input.nextLine().charAt(0);
                    do {
                        ch = input.nextLine().charAt(0);
                        // check the coin
                        if (ch == 'A' || ch == 'a') {

                            // create a coin object of type nickel
                            Coins coin = new Coins("nickel", 0.05);
                            // add coin to vending machine and keep track of its quantity
                            coinsRemoved.add(coin);
                        } else if (ch == 'B' || ch == 'b') {
                            // create a coin object of type dime
                            Coins coin = new Coins("dime", 0.1);
                            // add coin to vending machine and keep track of its quantity
                            coinsRemoved.add(coin);


                        } else if (ch == 'C' || ch == 'c') {
                            // create a coin object of type quarter
                            Coins coin = new Coins("quarter", 0.25);
                            // add coin to vending machine and keep track of its quantity
                            coinsRemoved.add(coin);

                        } else if (ch == 'D' || ch == 'd') {
                            // create a coin object of type penny
                            Coins coin = new Coins("penny", 0.01);
                            // add coin to vending machine and keep track of its quantity
                            coinsRemoved.add(coin);
                        } else {
                            System.err.println("Select a valid option");
                        }
                    }while(ch != 'x');

                    //verify the coins to be removed are the amount user specified
                    double coinsToRemove = vendingMachine.getMoneyInCoins(coinsRemoved);
                    if (coinsToRemove != amountToRemove) {
                        System.err.println("The amounts you selected do not match");
                    } else {
                        vendingMachine.removeMoney(coinsRemoved);
                    }
                }

            }
            //QUIT
            else if (ch == 'Q' || ch == 'q') {
                System.out.println("See you next time! Thanks");
                break;
            } else {
                System.err.println("Please select a valid option from the menu!");
            }
        }//end loop
        input.close(); //stop taking input


    }
}
