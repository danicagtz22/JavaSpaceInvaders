package edu.uchicago.gerber._06design.E0_4;

public class Product {

    private String productDescription;

    private double price;

    private int quantity;

    // Constructor
    public Product(String description, double price, int quantity)
    {
        this.productDescription = description;
        this.price = price;
        this.quantity = quantity;
    }



    // get description
    public String getDescription() {
        return productDescription;
    }

    // get price of product
    public double getPrice() {
        return this.price;
    }


    // change the price of product
    public void setPrice(double price){
        this.price = price;
    }


    // remove x quantity of product
    public void removeProduct(int quantity) {
        this.quantity -= quantity;
    }

    //add product
    public void addProduct(int quantity) {
        this.quantity += quantity;
    }
}
