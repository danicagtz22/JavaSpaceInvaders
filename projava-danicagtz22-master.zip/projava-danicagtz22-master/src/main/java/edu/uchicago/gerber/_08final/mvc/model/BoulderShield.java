package edu.uchicago.gerber._08final.mvc.model;

import edu.uchicago.gerber._08final.mvc.controller.Game;

import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class BoulderShield extends Sprite {

    //This is the one-line boulder shield that appears three times
    private int strikes;
    public BoulderShield(int x, int y) {

        setOrientation(270);
        setRadius(100);
        setTeam(Team.FRIEND);
        setCenter(new Point(x, y));

        //cartesian points which define the shape of the polygon
        //defined the points on a cartesian grid
        List<Point> pntCs = new ArrayList<>();
        pntCs.add(new Point(0, 3));
        pntCs.add(new Point(3,3));
        pntCs.add(new Point(5, 2));
        pntCs.add(new Point(5,-3));
        pntCs.add(new Point(3, -3));
        pntCs.add(new Point(3,-1));
        pntCs.add(new Point(0, 1));
        pntCs.add(new Point(-3,-1));
        pntCs.add(new Point(-3,-3));
        pntCs.add(new Point(-5,-3));
        pntCs.add(new Point(-5,2));
        pntCs.add(new Point(-3,3));
        pntCs.add(new Point(0,3));




        setCartesians(pntCs);
    }

    public void setStrikes(){
        this.strikes += 1;
    }
    public int getStrikes(){
        return this.strikes;
    }

    public void shieldIsCompromised(){
        setColor(Color.ORANGE);
    }

    @Override
    public void draw(Graphics g) {
        super.draw(g);

    }

    @Override
    public boolean isProtected() {
        if (this.strikes < 3){
            return true;
        }else{
            return false;
        }
    }
}
