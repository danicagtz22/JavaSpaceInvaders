package edu.uchicago.gerber._06design.E0_4;

public class Coins {

    private double value;

    private String nameType;



    public Coins(String name, double value) {
        this.value = value;
        this.nameType = name;
    }

    /* get methods */
    public String getNameType() {
        return this.nameType;
    }

    public double getValue() {
        return this.value;
    }

    /* set methods */
    public void setNameType(String name) {
        this.nameType = name;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
