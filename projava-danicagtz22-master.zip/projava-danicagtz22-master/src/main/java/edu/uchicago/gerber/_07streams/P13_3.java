package edu.uchicago.gerber._07streams;

import java.util.*;

public class P13_3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter an integer number: ");
        long inputNumber = in.nextLong();
        System.out.println("These are all the combinations: "  );
        //create the different word combinations
        ArrayList<String> words = wordCombinations(String.valueOf(inputNumber));

        //sort the word list
        Collections.sort(words);

        //print every word combination
        for (String word : words){
            System.out.println(word + "\n" );
        }

    }


    //create an array of strings that mimics a phone number pad
    private static String[] phoneLetters = {" ", " ", "abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz"};

    public static ArrayList<String> wordCombinations(String str){

        //base case, the string is empty
        if (str.length() == 0){
            ArrayList<String> output = new ArrayList<>();
            output.add("");
            return output;
        }

        //get the first character of the string
        char firstChar = str.charAt(0);

        //the remaining characters
        String remainingChars = str.substring(1);

        //recursive call
        ArrayList<String> characters = wordCombinations(remainingChars);

        ArrayList<String> finalWordList = new ArrayList<>();

        String phoneLetterSet = phoneLetters[Character.getNumericValue(firstChar)];

        for(String character : characters){
            for(int i = 0; i < phoneLetterSet.length(); i++) {
                //create the combinations  character by character
                finalWordList.add(phoneLetterSet.charAt(i) + character);
            }
        }
        return finalWordList;
    }
}
