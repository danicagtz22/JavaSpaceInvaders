package edu.uchicago.gerber._05dice;
import java.awt.*;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JFrame;
import javax.swing.JTextArea;

public class RestaurantBillMaker extends JFrame{


    private JLabel restaurantName;
    private double bill;
    //Creates an array of button objects for menu items
    private JButton[] menuItems;
    private JButton calculateFinalBill; //Add up the final bill button

    private JButton clear; //deletes all actions and sets the bill to 0

    private JLabel popularItem;

    private JLabel popularItemPrice;

    private JLabel gratuity;

    private JLabel estimatedGratuity;

    private JLabel grandTotalAmount;
    private JLabel pricesAdded;

    private JTextArea editFinalBill;
    private JTextField grandTotal; // adds gratuity and tax

    private JTextField menuItem; //For unpopular items that need to be added manually
    private JTextField menuItemPrice; //For unpopular items that need to be added manually
    private JTextField totalBillAmount; //For editing the final bill amount


    public RestaurantBillMaker() {


        build();
        restaurantName = new JLabel("Danica's Cafe");
        restaurantName.setFont(new Font("Serif", Font.ITALIC, 48));
        add(restaurantName, BorderLayout.CENTER);

    }


    private void build() {
        //App is divided into two columns according to the grid layout option
        setLayout(new GridLayout(13, 2));
        bill = 0;
        menuItems = new JButton[10];
        menuItems[0] = new JButton("Lavender Latte | $6.00");
        menuItems[1] = new JButton("Cappuccino | $5.00");
        menuItems[2] = new JButton("Mocha | $5.00");
        menuItems[3] = new JButton("Matcha | $5.50");
        menuItems[4] = new JButton("Vanilla Latte | $4.50");
        menuItems[5] = new JButton("Iced Tea | $3.00");
        menuItems[6] = new JButton("Blueberry Scone | $3.00");
        menuItems[7] = new JButton("Cinnamon Roll | $3.00");
        menuItems[8] = new JButton("Butter Croissant | $3.00");
        menuItems[9] = new JButton("Banana Muffin | $2.75");





        popularItem = new JLabel("Other Items");
        add(popularItem);
        popularItemPrice = new JLabel("Price");
        add(popularItemPrice);
        menuItem = new JTextField();
        add(menuItem);
        menuItemPrice = new JTextField();
        add(menuItemPrice);

        //Calculates good amount minus gratuity and tax
        pricesAdded = new JLabel("Total cost = ");
        add(pricesAdded);
        totalBillAmount = new JTextField();
        add(totalBillAmount);

        //Calculates suggested gratuity
        gratuity = new JLabel("Recommended gratuity (18%) ");
        add(gratuity);
        estimatedGratuity = new JLabel();
        add(estimatedGratuity);

        //calculates grand total with gratuity and tax
        grandTotalAmount = new JLabel("Grand Total (inc. 10% tax) = ");
        add(grandTotalAmount);
        grandTotal = new JTextField();
        add(grandTotal);

        //Calculates bill
        calculateFinalBill = new JButton("Calculate bill");
        add(calculateFinalBill);
        ActionListener calculateFinalBillListenerobj = new calculateFinalBillListener();
        calculateFinalBill.addActionListener(calculateFinalBillListenerobj);

        //clear account
        clear = new JButton("Clear");
        add(clear);
        ActionListener clearObj = new clear();
        clear.addActionListener(clearObj);

        //every button
        for (JButton button : menuItems) {
            ActionListener buttonAddupObj = new buttonAddup();
            button.addActionListener(buttonAddupObj);
            add(button);
        }

    }

    class calculateFinalBillListener implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            String s = menuItemPrice.getText();
            if (s.length() > 0) {
                double additionalCost = Double.parseDouble(s);
                bill += additionalCost;

            }
            totalBillAmount.setText(bill + "");
            estimatedGratuity.setText(bill * 0.18 + "");
            double tipAndTaxTotal = (bill * 1.1) + (bill * 0.18);
            grandTotal.setText(tipAndTaxTotal + "");
        }
    }

    class clear implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            bill = 0;
            totalBillAmount.setText(bill + "");
            grandTotal.setText(bill + "");
            estimatedGratuity.setText(bill + "");
        }
    }

    class buttonAddup implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            switch (event.getActionCommand()) {

                case "Lavender Latte | $6.00":
                    bill += 6;
                    break;

                case "Cappuccino | $5.00":
                    bill += 5;
                    break;

                case "Mocha | $5.00":
                    bill += 5;
                    break;

                case "Matcha | $5.50":
                    bill += 5.50;
                    break;

                case "Vanilla Latte | $4.50":
                    bill += 4.50;
                    break;

                case "Iced Tea | $3.00":
                    bill += 3;
                    break;

                case "Blueberry Scone | $3.00":
                    bill += 3;
                    break;

                case "Cinnamon Roll | $3.00":
                    bill += 3;
                    break;

                case "Butter Croissant | $3.00":
                    bill += 3;
                    break;

                case "Banana Muffin | $2.75":
                    bill += 2.75;
                    break;
            }
        }

    }
}
