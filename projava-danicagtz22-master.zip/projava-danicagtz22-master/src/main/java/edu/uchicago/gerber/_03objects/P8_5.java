package edu.uchicago.gerber._03objects;

import java.util.Scanner;

public class P8_5 {
    public static void main(String[] args)
    {

        //specification does not as to make this interactive

        Scanner in = new Scanner(System.in);
        // Use Scanner object to get user input
        System.out.println("Enter a soda can height in inches");
        String height = in.nextLine();

        System.out.println("Enter a soda can radius in inches");
        String radius = in.nextLine();

        SodaCan mySodaCan = new SodaCan(Integer.parseInt(height), Integer.parseInt(radius));
        double mySA = mySodaCan.getSurfaceArea();
        double myVolume = mySodaCan.getVolume();
        System.out.println("Can surface area is " + Double.toString(mySA) + " square inches");
        System.out.println("Can volume is " + Double.toString(myVolume) + " cubed inches");


    }
}


class SodaCan
{

    //Private variables
    private int height = 0;

    private int radius = 0;

    //constructor
    public SodaCan( int height, int radius ) {
        this.height = height;
        this.radius = radius;

    }


    public double getSurfaceArea(){
        double sa = 2 * Math.PI * this.radius * (this.radius + this.height);
        return sa;
    }

    public double getVolume(){

        double volume = Math.PI * this.radius * this.radius * this.height;
        return volume;
    }


}