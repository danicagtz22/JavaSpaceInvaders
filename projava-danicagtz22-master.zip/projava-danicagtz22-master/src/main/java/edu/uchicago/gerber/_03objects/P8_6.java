package edu.uchicago.gerber._03objects;

public class P8_6 {
    public static void main(String[] args)
    {

        //specification does not as to make this interactive

        Car myHybrid = new Car(50);
        myHybrid.addGas(20);
        myHybrid.Drive(100);
        System.out.println("Gas level is: " + myHybrid.getGasLevel());

    }
}


class Car
{

    //Private variables
    private double efficiency = 0; // miles/gallon

    private double fuel = 0;



    //constructor
    public Car( int efficiency ) {
        this.efficiency = efficiency;

    }


    public void Drive(int miles){

        double gallonsUsed = miles/this.efficiency;
        this.fuel -= gallonsUsed;

    }

    public double getGasLevel() {
        return this.fuel;
    }

    public double addGas (int gas){
        this.fuel += gas;
        return this.fuel;
    }



}