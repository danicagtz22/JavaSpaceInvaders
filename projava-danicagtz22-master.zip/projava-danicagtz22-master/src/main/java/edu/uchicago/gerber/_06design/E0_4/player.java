package edu.uchicago.gerber._06design.E0_4;

public class player {

    private int level;

    private int playerScore;

    private String playerName;


    public player(){
        this.level = 1;
        this.playerScore = 0;
    }

    public int getLevel(){
        return this.level;
    }

    public void setLevel(int level){
        this.level = level;
    }

    public int getPlayerScore(){
       return  this.playerScore;
    }

    public void setPlayerScore(int points){
        this.playerScore += points;
    }
}
