package edu.uchicago.gerber._03objects;

import java.util.ArrayList;
import java.util.List;

public class P8_14 {
    public static void main(String[] args)
    {
        //specification does not ask to make this interactive

        Country country1 =  new Country("China", 1425893465,9706961 );
        Country country2 =  new Country("India", 1407563842,3287590 );
        Country country3 =  new Country("US", 336997624,9372610 );

        List<Country> list = new ArrayList<Country>();

        list.add(country1);
        list.add(country2);
        list.add(country3);

        double area = 0;
        double population = 0;
        double density = 0;

        String countryArea = "";
        String countryPopulation = "";
        String countryDensity = "";
        for (Country country : list)
        {
            if (area < country.getArea())
            {
                area = country.getArea();
                countryArea = country.getName();
            }

            if (population < country.getPopulation())
            {
                population = country.getPopulation();
                countryPopulation = country.getName();
            }

            if (density < country.getPopulationDensity())
            {
                density = country.getPopulationDensity();
                countryDensity = country.getName();
            }

        }

        System.out.println("Country with largest area:  " + countryArea);
        System.out.println("Country with largest population:  " + countryPopulation);
        System.out.println("Country with largest density:  " + countryDensity);



    }
}


class Country
{

    //Private variables
    private String name;

    private double population;

    private double area;

    private double populationDensity;

    public String getName(){
        return this.name;
    }
    public double getPopulation(){
        return this.population;
    }
    public double getArea(){
        return this.area;
    }
    public double getPopulationDensity(){
        return this.populationDensity;
    }


    //constructor
    public Country( String name, int population, double area ) {
        this.name = name;
        this.population = population;
        this.area = area;
        this.populationDensity = this.population / this.area;

    }





}