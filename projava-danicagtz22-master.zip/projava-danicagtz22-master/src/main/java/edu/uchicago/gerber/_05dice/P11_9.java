package edu.uchicago.gerber._05dice;
import javax.swing.*;


public class P11_9 {

    public static void main(String[] args){
        JFrame frame = new JFrame("Draw Me a Circle!");
        frame.add(new MyCircle());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
