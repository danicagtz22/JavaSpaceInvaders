package edu.uchicago.gerber._08final.mvc.controller;

import edu.uchicago.gerber._08final.mvc.model.*;
import edu.uchicago.gerber._08final.mvc.view.GamePanel;


import javax.sound.sampled.Clip;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Comparator;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Collectors;

// ===============================================
// == This Game class is the CONTROLLER
// ===============================================

public class Game implements Runnable, KeyListener {

	// ===============================================
	// FIELDS
	// ===============================================

	public static final Dimension DIM = new Dimension(1100, 900); //the dimension of the game.
	private GamePanel gmpPanel;

	private boolean flap = true;
	//this is used throughout many classes.
	public static Random R = new Random();

	public final static int ANI_DELAY = 40; // milliseconds between screen
											// updates (animation)

	public final static int FRAMES_PER_SECOND = 1000 / ANI_DELAY;

	private Thread animationThread;

	//todo this is state: move to CommandCenter
	private boolean muted = true;
	

	private final int PAUSE = 80, // p key
			QUIT = 81, // q key
			LEFT = 37, // rotate left; left arrow
			RIGHT = 39, // rotate right; right arrow
			UP = 38, // thrust; up arrow
			START = 83, // s key
			FIRE = 32, // space key
			MUTE = 77; // m-key mute

	// for possible future use
	// HYPER = 68, 					// D key
	// SHIELD = 65, 				// A key
	// SPECIAL = 70; 					// fire special weapon;  F key

	private Clip clpThrust;
	private Clip clpMusicBackground;

	//spawn every 30 seconds
	private static final int SPAWN_NEW_SHIP_FLOATER = FRAMES_PER_SECOND * 30;
	private static final int ALIEN_FIRE =  FRAMES_PER_SECOND * 1;





	// ===============================================
	// ==CONSTRUCTOR
	// ===============================================

	public Game() {

		gmpPanel = new GamePanel(DIM);
		gmpPanel.addKeyListener(this); //Game object implements KeyListener
		clpThrust = Sound.clipForLoopFactory("whitenoise.wav");
		clpMusicBackground = Sound.clipForLoopFactory("music-background.wav");

		//fire up the animation thread
		animationThread = new Thread(this); // pass the animation thread a runnable object, the Game object
		animationThread.start();
	

	}

	// ===============================================
	// ==METHODS
	// ===============================================

	public static void main(String args[]) {
		//typical Swing application start; we pass EventQueue a Runnable object.
		EventQueue.invokeLater(Game::new);
	}

	// Game implements runnable, and must have run method
	@Override
	public void run() {

		// lower animation thread's priority, thereby yielding to the "main" aka 'Event Dispatch'
		// thread which listens to keystrokes
		animationThread.setPriority(Thread.MIN_PRIORITY);

		// and get the current time
		long lStartTime = System.currentTimeMillis();

		// this thread animates the scene
		while (Thread.currentThread() == animationThread) {

			gmpPanel.update(gmpPanel.getGraphics()); // see GamePanel class
			checkCollisions();
			checkNewLevel();
			checkAliens();
			flapAliens();
			aliensFire();
			spawnNewShipFloater();
			spawnAlienBonusShield();


				// surround the sleep() in a try/catch block
			// this simply controls delay time between
			// the frames of the animation
			try {
				// The total amount of time is guaranteed to be at least ANI_DELAY long.  If processing (update) 
				// between frames takes longer than ANI_DELAY, then the difference between lStartTime - 
				// System.currentTimeMillis() will be negative, then zero will be the sleep time
				lStartTime += ANI_DELAY;

				Thread.sleep(Math.max(0,
						lStartTime - System.currentTimeMillis()));
			} catch (InterruptedException e) {
				// do nothing (bury the exception), and just continue, e.g. skip this frame -- no big deal
			}
		} // end while
	} // end run


	private void checkAliens(){

		boolean rotateAll = false;
		for (Movable movFoe : CommandCenter.getInstance().getMovFoes()) {
			if (movFoe instanceof  Alien){
				//check for bounds
				Alien alien = (Alien) movFoe;
				if (alien.getCenter().x + alien.getRadius() > Game.DIM.width){
					rotateAll = true;
					break;
				}
				if (alien.getCenter().x - alien.getRadius() < 0){
					rotateAll = true;
					break;
				}
			}
		}
		if (rotateAll) {
			CommandCenter.getInstance().getMovFoes().stream()
					.filter(m -> m instanceof Alien)
					.map(m -> (Alien) m)
					.forEach(Alien::rotate);
		}


	}

	//This allows for the Aliens to move by flapping their wings

	private void flapAliens(){

		if ((System.currentTimeMillis() / ANI_DELAY) % 10  == 0) {
			flap = !flap;
			CommandCenter.getInstance().getMovFoes().stream()
					.filter(m -> m instanceof Alien)
					.map(m -> (Alien) m)
					.forEach(a -> a.flap(flap));
		}
	}
	private void checkCollisions() {

		Point pntFriendCenter, pntFoeCenter;
		int radFriend, radFoe;

		//This has order-of-growth of O(n^2), there is no way around this.
		for (Movable movFriend : CommandCenter.getInstance().getMovFriends()) {
			for (Movable movFoe : CommandCenter.getInstance().getMovFoes()) {

				pntFriendCenter = movFriend.getCenter();
				pntFoeCenter = movFoe.getCenter();
				radFriend = movFriend.getRadius();
				radFoe = movFoe.getRadius();

				//detect collision
				if (pntFriendCenter.distance(pntFoeCenter) < (radFriend + radFoe)) {
					if(movFriend instanceof BoulderShield){
						Sound.playSound("kapow.wav");
						//each boulder can only take three strikes, it will disappear on the fourth
						((BoulderShield) movFriend).setStrikes();
						if(((BoulderShield) movFriend).getStrikes() == 2){
							((BoulderShield) movFriend).shieldIsCompromised();
						}
					}

					//remove the friend (so long as he is not protected)
					if (!movFriend.isProtected()){
						if(movFriend instanceof Bullet){

							Sound.playSound("kapow.wav");
						}else if(movFriend instanceof BrickBoulderShield){
							Sound.playSound("rock.wav");
						}else{
							Sound.playSound("boulderExplosion.wav");
						}
						CommandCenter.getInstance().getOpsQueue().enqueue(movFriend, GameOp.Action.REMOVE);


					}

					if(movFoe instanceof NewShipFloater){
						//red aliens are worth 10 points
						CommandCenter.getInstance().addPointsToScore(10);
						Sound.playSound("kapow.wav");
						CommandCenter.getInstance().getOpsQueue().enqueue(movFoe, GameOp.Action.REMOVE);
					}
					if(movFoe instanceof AlienBonusShield){
						//blue aliens give you an extra shield
						Sound.playSound("kapow.wav");
						buildWall();
						CommandCenter.getInstance().getOpsQueue().enqueue(movFoe, GameOp.Action.REMOVE);
					}
					else {

						//set up explosion
						if(movFriend instanceof Falcon){
							((Bomb) movFoe).setCollision();
							movFoe.move();
						}
						//remove the foe
						CommandCenter.getInstance().getOpsQueue().enqueue(movFoe, GameOp.Action.REMOVE);
						//call add, rather than automatic setter
						if(movFoe instanceof Alien){
							CommandCenter.getInstance().addPointsToScore(1);
							Sound.playSound("kapow.wav");
						}
						CommandCenter.generateDebris((Sprite) movFoe);


					}


				 }

			}//end inner for
		}//end outer for

		//check for collisions between falcon and floaters. Order of growth of O(n) where n is number of floaters
		Point pntFalCenter = CommandCenter.getInstance().getFalcon().getCenter();
		int radFalcon = CommandCenter.getInstance().getFalcon().getRadius();

		Point pntFloaterCenter;
		int radFloater;
		for (Movable movFloater : CommandCenter.getInstance().getMovFloaters()) {
			pntFloaterCenter = movFloater.getCenter();
			radFloater = movFloater.getRadius();
	
			//detect collision
			if (pntFalCenter.distance(pntFloaterCenter) < (radFalcon + radFloater)) {

				CommandCenter.getInstance().getOpsQueue().enqueue(movFloater, GameOp.Action.REMOVE);
				Sound.playSound("pacman_eatghost.wav");
	
			}//end if
		}//end for

		processGameOpsQueue();

	}//end meth

	private void processGameOpsQueue() {

		//deferred mutation: these operations are done AFTER we have completed our collision detection to avoid
		// mutating the movable linkedlists while iterating them above
		while(!CommandCenter.getInstance().getOpsQueue().isEmpty()){
			GameOp gameOp =  CommandCenter.getInstance().getOpsQueue().dequeue();
			Movable mov = gameOp.getMovable();
			GameOp.Action action = gameOp.getAction();

			switch (mov.getTeam()){
				case FOE:
					if (action == GameOp.Action.ADD){
						CommandCenter.getInstance().getMovFoes().add(mov);
					} else {
						CommandCenter.getInstance().getMovFoes().remove(mov);

					}

					break;
				case FRIEND:
					if (action == GameOp.Action.ADD){
						CommandCenter.getInstance().getMovFriends().add(mov);
					} else {
						if (mov instanceof Falcon) {
							CommandCenter.getInstance().initFalconAndDecrementFalconNum();
						} else {
							CommandCenter.getInstance().getMovFriends().remove(mov);
						}
					}
					break;

				case FLOATER:
					if (action == GameOp.Action.ADD){
						CommandCenter.getInstance().getMovFloaters().add(mov);
					} else {
						CommandCenter.getInstance().getMovFloaters().remove(mov);
					}
					break;

				case DEBRIS:
					if (action == GameOp.Action.ADD){
						CommandCenter.getInstance().getMovDebris().add(mov);
					} else {
						CommandCenter.getInstance().getMovDebris().remove(mov);
					}
					break;


			}

		}
	}


	private void spawnNewShipFloater() {

		//appears more often as your level increases.
		if ((System.currentTimeMillis() / ANI_DELAY) % (SPAWN_NEW_SHIP_FLOATER - CommandCenter.getInstance().getLevel() * 2L) == 0) {
			CommandCenter.getInstance().getOpsQueue().enqueue(new NewShipFloater(5), GameOp.Action.ADD);
			Sound.playSound("flyingenemy.wav");

		}
	}

	//This is for the blue alien that gives you an additional shield if you strike it
	private void spawnAlienBonusShield() {

		//appears more often as your level increases.
		if ((System.currentTimeMillis() / ANI_DELAY + 90) % (SPAWN_NEW_SHIP_FLOATER - CommandCenter.getInstance().getLevel() * 2L) == 0 ) {
			CommandCenter.getInstance().getOpsQueue().enqueue(new AlienBonusShield(5), GameOp.Action.ADD);
			Sound.playSound("flyingenemy.wav");

		}
	}


	private void aliensFire(){
		//every 5 secs - currently
		if ((System.currentTimeMillis() / ANI_DELAY) % ALIEN_FIRE  == 0) {
			System.out.println("ALIEN FIRES");
			//get all foes as stream
			//filter Aliens only
			//sort by highest centerPoint.y (lowest on screen)
			//limit to 5 max
			//cast to Alien
			//get a random among the 3 lowest
			AtomicInteger numAlienInLowList = new AtomicInteger(5);
			Optional<Alien> optionalAlien = CommandCenter.getInstance().getMovFoes().stream()
					.filter(m -> m instanceof Alien)
					.sorted(new Comparator<Movable>() {
						@Override
						public int compare(Movable m1, Movable m2) {
							return Integer.compare(m2.getCenter().y, m1.getCenter().y);
						}
					})
					.limit(numAlienInLowList.get())
					.map(m -> (Alien) m)
					.skip((int) (Math.random() * numAlienInLowList.get()))
					.findFirst();


			//alien fires
			optionalAlien.ifPresent(alien -> {
				CommandCenter.getInstance().getOpsQueue().enqueue(new Bomb(alien), GameOp.Action.ADD);
			});


		}
	}
	
	private boolean isLevelClear(){
		//if there are no more Aliens on the screen
		boolean alienFree = true;
		for (Movable movFoe : CommandCenter.getInstance().getMovFoes()) {
			if (movFoe instanceof Alien){
				alienFree = false;
				break;
			}
		}
		return alienFree;
	}
	
	private void checkNewLevel(){
		
		if (isLevelClear()) {
			CommandCenter.getInstance().setLevel(CommandCenter.getInstance().getLevel() + 1);
			CommandCenter.getInstance().getFalcon().setFade(Falcon.FADE_INITIAL_VALUE);
			CommandCenter.getInstance().createNewAliens(CommandCenter.getInstance().getLevel());
			CommandCenter.getInstance().createBoulderShields();


		}
	}
	
	
	

	// Varargs for stopping looping-music-clips
	private static void stopLoopingSounds(Clip... clpClips) {
		for (Clip clp : clpClips) {
			clp.stop();
		}
	}

	// ===============================================
	// KEYLISTENER METHODS
	// ===============================================

	@Override
	public void keyPressed(KeyEvent e) {
		Falcon fal = CommandCenter.getInstance().getFalcon();
		int nKey = e.getKeyCode();

		if (nKey == START && CommandCenter.getInstance().isGameOver())
			CommandCenter.getInstance().initGame();

		if (fal != null) {

			switch (nKey) {
			case PAUSE:
				CommandCenter.getInstance().setPaused(!CommandCenter.getInstance().isPaused());
				if (CommandCenter.getInstance().isPaused())
					stopLoopingSounds(clpMusicBackground, clpThrust);

				break;
			case QUIT:
				System.exit(0);
				break;
			case UP:
				fal.thrustOn();
				if (!CommandCenter.getInstance().isPaused() && !CommandCenter.getInstance().isGameOver())
					clpThrust.loop(Clip.LOOP_CONTINUOUSLY);
				break;
			case LEFT:
				fal.rotateLeft();
				break;
			case RIGHT:
				fal.rotateRight();
				break;

			default:
				break;
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		Falcon fal = CommandCenter.getInstance().getFalcon();
		int nKey = e.getKeyCode();
		//show the key-code in the console
		 System.out.println(nKey);

		if (fal != null) {
			switch (nKey) {
			case FIRE:
				CommandCenter.getInstance().getOpsQueue().enqueue(new Bullet(fal), GameOp.Action.ADD);
				Sound.playSound("laser.wav");
				break;

			case LEFT:
				fal.stopRotating();
				break;
			case RIGHT:
				fal.stopRotating();
				break;
			case UP:
				fal.thrustOff();
				clpThrust.stop();
				break;
				
			case MUTE:
				if (!muted){
					stopLoopingSounds(clpMusicBackground);
				} 
				else {
					clpMusicBackground.loop(Clip.LOOP_CONTINUOUSLY);
				}
				muted = !muted;
				break;
				
			default:
				break;
			}
		}
	}

	@Override
	// does nothing, but we need it b/c of KeyListener contract
	public void keyTyped(KeyEvent e) {
	}


	//shows how to add walls or rectangular elements one
	//brick at a time
	private void buildWall() {
		final int BRICK_SIZE = Game.DIM.width / 30, ROWS = 5, COLS = 1, X_OFFSET = BRICK_SIZE * 5, Y_OFFSET = 50;

		for (int nRow = 0; nRow < ROWS; nRow++) {
			for (int nCol = 0; nCol < COLS; nCol++) {
				CommandCenter.getInstance().getOpsQueue().enqueue(
						new BrickBoulderShield(
								new Point(nRow * BRICK_SIZE + X_OFFSET + 285, nCol * BRICK_SIZE + Y_OFFSET + 500),
								BRICK_SIZE),
						GameOp.Action.ADD);

			}
		}
	}


}


