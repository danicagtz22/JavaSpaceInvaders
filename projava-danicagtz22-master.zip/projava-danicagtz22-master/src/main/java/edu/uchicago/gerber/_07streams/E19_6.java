package edu.uchicago.gerber._07streams;

import java.util.Currency;
import java.util.Set;
import java.util.stream.Collectors;

//The static getAvailableCurrencies method of the java.util.Currency class yields a set of Currency objects.
// turn it into a stream and transform it into a stream of the currency display names. Print them in sorted order.
public class E19_6 {

    public static void main(String args[]) {
        Set<Currency> currencySet =  Currency.getAvailableCurrencies();

        currencySet.stream()
                .map(elem -> elem.toString())
                .sorted()
                .collect(Collectors.toList())
                .forEach(elem -> System.out.println(elem));


    }
}
