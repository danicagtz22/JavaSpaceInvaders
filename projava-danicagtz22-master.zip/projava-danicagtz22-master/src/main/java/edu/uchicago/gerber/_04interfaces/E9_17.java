package edu.uchicago.gerber._04interfaces;

import java.util.Scanner;

public class E9_17 {
    public static void main(String[] args)
    {


        Scanner in = new Scanner(System.in);

        //Enter the size of the array
        System.out.println("Enter the number of soda cans in the array to get their average surface area");
        int sodaCans = in.nextInt();


        //Initiate array according to specified size
        Measurable[] sodas = new SodaCan[sodaCans];
        for(int i = 0; i < sodaCans ; i++)
        {
            // Use Scanner object to get user input
            System.out.println("Enter a soda can height in inches");
            int height = in.nextInt();

            System.out.println("Enter a soda can radius in inches");
            int radius = in.nextInt();

            sodas[i] = new SodaCan(height, radius);

        }

        System.out.println("The average surface area of the soda cans in the array is: " + average(sodas) + " square inches");



    }

    //method to compute universal average
    public static double average(Measurable[] objs )
    {
        if(objs.length == 0 ){ return 0;}
        double sum = 0;
        for (Measurable obj : objs)
        {
            sum = sum + obj.getMeasure();
        }
        return sum / objs.length;
    }

}


class SodaCan implements Measurable
{

    //Private variables
    private int height = 0;

    private int radius = 0;

    //constructor
    public SodaCan( int height, int radius ) {
        this.height = height;
        this.radius = radius;

    }


    public double getSurfaceArea(){
        double sa = 2 * Math.PI * this.radius * (this.radius + this.height);
        return sa;
    }

    public double getVolume(){

        double volume = Math.PI * this.radius * this.radius * this.height;
        return volume;
    }

    public double getMeasure() {
        double surfaceArea= this.getSurfaceArea();
        return surfaceArea;
    }
}