package edu.uchicago.gerber._04interfaces;


import java.util.Scanner;

public class E9_11 {


    public static void main(String[] args)
    {

        Student student1 = new Student("Anthropology");
        student1.setName("Tobias");
        student1.setBirthYear(1998);
        Instructor prof = new Instructor(130_000);
        prof.setName("Raymond");
        prof.setBirthYear(1969);


        System.out.println(student1.toString());
        System.out.println(prof.toString());



    }
}


class  Person{

    private String name;

    private int birthYear;

    public Person(){

    }
    public String toString(){
        return "Name : " + name + "\nBirth Year: " + birthYear + "\n";
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }
    public int getBirthYear(){
        return birthYear;
    }

    public void setBirthYear(int year){
        birthYear = year;
    }

}
class Student extends Person{
    private String major;
    public Student(String major){
    this.major = major;
    }

    public String toString(){

        return super.toString() + "Major: " + major;
    }

}
class Instructor extends Person{
    private double salary;
    public Instructor(double salary){
        this.salary = salary;
    }

    public String toString(){

        return super.toString() + "Salary: " + salary;
    }


}