package edu.uchicago.gerber._08final.mvc.model;

import edu.uchicago.gerber._08final.mvc.controller.Game;

import java.awt.*;

public class Explosion extends Sprite{

    public Explosion(Point[] twoPoints, Sprite sprite) {

        setCenter(twoPoints[0]);
        setCartesians(twoPoints);
        setExpiry(20);
        setColor(Color.YELLOW);
        setTeam(Team.DEBRIS);
        setSpin(80);
        setRadius(100);

        if(sprite instanceof Alien){
            setColor(Color.GREEN);
        } else if (sprite instanceof BoulderShield) {
            setColor(Color.ORANGE);
        }

    }


}
