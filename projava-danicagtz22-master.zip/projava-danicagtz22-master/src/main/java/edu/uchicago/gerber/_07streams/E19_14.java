package edu.uchicago.gerber._07streams;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/* Read all words from a file into an ArrayList<String>, then turn it into a parallel stream. Use the dictionary
file words.txt provided with the book's companion code. Use filters and the findAny method to find any palindrome
that has at least five letters , then print the word.
What happens when you run the program multiple times?
 */

//WHAT HAPPENS WHEN YOU RUN THE PROGRAM MULTIPLE TIMES?
/// WHEN YOU RUN THE PROGRAM MULTIPLE TIMES the answer CAN change because it's a parallel stream and one processor
/// could return an answer before another one when there are many words like in this case.
public class E19_14 {
    public static void main(String[] args) {

        try (BufferedReader reader = new BufferedReader(new FileReader("warandpeace.txt")))
        {
            //reads all the files from War and Peace .txt file, makes the lower case and adds them to an ArrayList<String>
            ArrayList<String> list = new ArrayList<>();
            while (reader.ready()) {
                String[] s = reader.readLine().split("\\s");
                for(int i=0; i < s.length ; i++){
                    list.add(s[i].toLowerCase());
                }
            }

            //findAny() is a terminal method that returns an Optional<T> result, so isPresent() is used to avoid an exception
           Optional<String> result =  list.stream().parallel().filter(w -> w.length() >= 5).filter(w -> isPalindrome(w)).findAny();

            if (result.isPresent()) {
                System.out.println(result.get());
            }
            else {
                System.out.println("NO RESULT TO SHOW");
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    //this method uses IntStream to test whether a string is a palindrome
    public static boolean isPalindrome(String word) {
        return IntStream.range(0, word.length() / 2)
                .noneMatch(i -> word.charAt(i) != word.charAt(word.length() - i - 1));
    }



}
