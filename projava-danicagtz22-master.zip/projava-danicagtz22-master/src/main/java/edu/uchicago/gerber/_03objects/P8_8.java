package edu.uchicago.gerber._03objects;

public class P8_8 {
    public static void main(String[] args)
    {
        //specification does not as to make this interactive
        VotingMachine myElection = new VotingMachine();
        myElection.demVotes(20);
        myElection.repVotes(15);
        myElection.getAllVotes();
        myElection.resetMachineVotes();
        System.out.println(myElection.getDemVotes());

    }
}


class VotingMachine
{

    //Private variables
    private int democratVotes = 0;

    private int republicanVotes = 0;





    //constructor
    public VotingMachine( ) {

    }


    public void demVotes(int votes){

        this.democratVotes = this.democratVotes + votes;

    }

    public void repVotes(int votes){

        this.republicanVotes = this.republicanVotes + votes;

    }

    public void resetMachineVotes(){
        this.democratVotes = 0;
        this.democratVotes = 0;
    }

    public int getDemVotes (){
        return this.democratVotes;
    }
    public int getRepVotes (){
        return this.republicanVotes;
    }

    public void getAllVotes(){
        System.out.println("There are " + (this.democratVotes + this.republicanVotes ) + " total votes. ");
        System.out.println(this.democratVotes + " votes for democrats. " + this.republicanVotes + " votes for republicans");
    }

}