package edu.uchicago.gerber._02arrays;
import java.util.Random;


public class E6_1 {

    public static void main(String []args){

        // Create a random object
        Random rd = new Random();
        //initialize an array with ten elements (note that all values are initially set to 0)
        int[] elemArray = new int[10];
        //All elements
        System.out.println("All array elements:" );
        // iterate through the array and generate a random int for each element

        for (int i = 0; i < elemArray.length; i++) {
            elemArray[i] = rd.nextInt();
            System.out.println(elemArray[i]); //print each element
        }

        //Every element at an even index
        System.out.println("Every element at an even index:" );
        //We start at index 0 and add 2 every time to get all the even indices (0, 2, 4, 6, 8)
        for (int i = 0; i < elemArray.length; i = i+2) {
            System.out.println(elemArray[i]);
        }

        //Every even element
        System.out.println("Every even element:" );
        //An element is even if it leaves no remainder when divided by 2
        for (int i = 0; i < elemArray.length; i++) {
            if(elemArray[i] % 2 == 0){
                System.out.println(elemArray[i]);
            }
        }

        //Printing the array in reverse order
        System.out.println("Array in reverse order:" );
        //Iterate through the array but we start at the last element's index and subtract our way down to the beginning of the array
        for (int i = elemArray.length-1; i >= 0; i--) {
                System.out.println(elemArray[i]);
        }

        //Printing only the first and last element
        System.out.println("First element: " + elemArray[0] + " Last element: " + elemArray[9]);
    }

}


