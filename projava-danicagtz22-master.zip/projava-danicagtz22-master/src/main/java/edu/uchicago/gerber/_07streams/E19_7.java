package edu.uchicago.gerber._07streams;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Stream;

/* write a lambda expression for a function that turns a string into a string made of the first letter, three periods,
and the last letter, such as "W...d". (Assume the string has at least two letters .) Then write a program that reads words
into a stream, applies the lambda expression to each element , and prints the result. filter out any words with fewer than two letters
 */
public class E19_7 {

    public static void main(String[] args) throws IOException {
        System.out.println(System.getProperty("user.dir"));
        Scanner in = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String test = in.nextLine();
        streamWords(test);

        System.out.print("\nWould you like to read words from a file? yes/no: ");
        String read = in.nextLine();

        if(read.equals("yes")){
            System.out.print("What's the file name? ");
            String filename = in.nextLine();
            Stream<String> lines = Files.lines(Paths.get(filename));
                        lines
                        .flatMap(line->Arrays.stream(line.split("\\s+")))
                        .filter(w -> w.length() > 2)
                        .map(word -> word.charAt(0) + "..." + word.charAt(word.length()-1))
                        .forEach(newword -> System.out.println(newword));

        }


    }

    public static void streamWords(String s) {
        if(s.length() < 2){
            System.out.print("Strings with less than two characters are ignored");
        }
            String[] result = s.split(" ");
            Arrays.stream(result)
                    .filter(w -> w.length() > 2)
                    .map(word -> word.charAt(0) + "..." + word.charAt(word.length()-1))
                    .forEach(newword -> System.out.println(newword));

    }
}
