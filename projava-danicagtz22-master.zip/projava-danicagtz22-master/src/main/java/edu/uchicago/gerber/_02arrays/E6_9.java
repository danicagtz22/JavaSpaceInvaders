package edu.uchicago.gerber._02arrays;
import java.util.Random;


public class E6_9 {
  //Write a method that checks whether two arrays have the same elements in the same order
    public static void main(String []args){

        int[] array1 = {1, 2, 5, 3, 4, 5};

        int[] array2 = {1, 2, 3, 4, 5};

        boolean arraysAreEqual = equals(array1, array2);

        if(!arraysAreEqual){
            System.out.println("Arrays are NOT the same" );
        } else{
            System.out.println("Arrays ARE the same" );
        }

    }

    public static boolean equals(int[] a, int[] b){
        boolean arraysAreEqual = false;
        //easy check for length
        if(a.length != b.length){
            return arraysAreEqual;
        }
        //assuming the arrays have the same length, we'll take the first array and compare each of its elements to the second array
        for (int i = 0; i < a.length; i++) {
            if(a[i] != b[i]){
                arraysAreEqual = false;
            }else{
                arraysAreEqual = true;
            }
        }
        return arraysAreEqual;
    }



}


