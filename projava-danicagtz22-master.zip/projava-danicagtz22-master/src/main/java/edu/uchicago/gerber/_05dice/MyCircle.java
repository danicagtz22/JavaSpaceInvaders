package edu.uchicago.gerber._05dice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MyCircle extends JComponent {

         private Point centerPoint;
         private Point circumferencePoint;

         public MyCircle()
         {
             setPreferredSize(new Dimension(500, 500));
             MouseListener listener = new MyMouseListener();
             addMouseListener(listener);

         }

        class MyMouseListener implements MouseListener
        {

                public void mouseClicked(MouseEvent e) {
                    //if there's only a point selected, that must be assigned to the center point first, then we assign or reassign the
                    // circumference point
                    if (centerPoint == null || circumferencePoint != null) {
                        centerPoint = e.getPoint();
                        circumferencePoint = null;
                    } else {
                        circumferencePoint = e.getPoint();
                    }
                    repaint();
                }
            //do nothing methods
            @Override
            public void mousePressed(MouseEvent e) {}
            @Override
            public void mouseReleased(MouseEvent e) {}
            @Override
            public void mouseEntered(MouseEvent e) {}
            @Override public void mouseExited(MouseEvent e) {}
        };

        protected void paintComponent(Graphics g)
        {
            super.paintComponent(g);
            if(centerPoint != null && circumferencePoint != null)
            {
                //calculate the circle radius by getting the distance from the centerPoint to the circumferencePoint
                int radius = (int) Math.round(centerPoint.distance(circumferencePoint));

                //the (x,y) is the top left corner of where the circle sits, so we calculate by subtracting the radius from the centerPoint
                g.drawOval(centerPoint.x - radius, centerPoint.y - radius, 2 * radius, 2 * radius);
            }
        }
}
