package edu.uchicago.gerber._04interfaces;

public interface Measurable {
    double getMeasure();
}
