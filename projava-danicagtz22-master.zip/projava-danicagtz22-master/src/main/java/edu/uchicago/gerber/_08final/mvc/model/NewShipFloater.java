package edu.uchicago.gerber._08final.mvc.model;

import edu.uchicago.gerber._08final.mvc.controller.Game;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class NewShipFloater extends Sprite {
	private boolean moveLeft = true;
	private int speed;


	public NewShipFloater(int speed) {

		this.speed = speed;
		setOrientation(270);
		setRadius(25);
		setTeam(Team.FOE);
		setExpiry(300);
		setCenter(new Point(Game.DIM.width - 80, 50));


		//cartesian points which define the shape of the polygon
		List<Point> pntCs = new ArrayList<>();
		pntCs.add(new Point(0,0));
		pntCs.add(new Point(2,0));
		pntCs.add(new Point(2,1));
		pntCs.add(new Point(1,1));
		pntCs.add(new Point(1,0));
		pntCs.add(new Point(2,0));
		pntCs.add(new Point(0,0));

		pntCs.add(new Point(0,2));
		pntCs.add(new Point(1,2));
		pntCs.add(new Point(1,3));
		pntCs.add(new Point(2,3));
		pntCs.add(new Point(2,4));
		pntCs.add(new Point(3,4));
		pntCs.add(new Point(3,3));
		pntCs.add(new Point(2, 3));
		pntCs.add(new Point(2,2));
		pntCs.add(new Point(3, 2));
		pntCs.add(new Point(3,1));
		pntCs.add(new Point(4, 1));
		pntCs.add(new Point(4,5));
		pntCs.add(new Point(5, 5));
		pntCs.add(new Point(5, 0));
		//bottom right
		pntCs.add(new Point(5, 0));
		pntCs.add(new Point(5,-1));
		pntCs.add(new Point(4,-1));
		pntCs.add(new Point(3, -1));
		pntCs.add(new Point(3,-3));
		pntCs.add(new Point(2, -3));
		pntCs.add(new Point(2,-4));
		pntCs.add(new Point(1,-4));
		pntCs.add(new Point(1,-3));
		pntCs.add(new Point(2,-3));
		pntCs.add(new Point(2,-2));
		pntCs.add(new Point(1,-2));
		pntCs.add(new Point(0,-2));
		//bottom left quadrant
		pntCs.add(new Point(-2,-2));
		pntCs.add(new Point(-2,-3));
		pntCs.add(new Point(-1,-3));
		pntCs.add(new Point(-1,-4));
		pntCs.add(new Point(-2,-4));
		pntCs.add(new Point(-2, -3));
		pntCs.add(new Point(-3,-3));
		pntCs.add(new Point(-3, -1));
		pntCs.add(new Point(-4,-1));
		pntCs.add(new Point(-5, -1));
		pntCs.add(new Point(-5,0));
		//top left quadrant
		pntCs.add(new Point(-5, 0));
		pntCs.add(new Point(-5, 5));
		pntCs.add(new Point(-4, 5));
		pntCs.add(new Point(-4,1));
		pntCs.add(new Point(-3,1));
		pntCs.add(new Point(-3, 2));
		pntCs.add(new Point(-2,2));
		pntCs.add(new Point(-2, 3));
		pntCs.add(new Point(-3,3));
		pntCs.add(new Point(-3,4));
		pntCs.add(new Point(-2,4));
		pntCs.add(new Point(-2,3));
		pntCs.add(new Point(-1,3));
		pntCs.add(new Point(-1,2));
		pntCs.add(new Point(0,2));

		pntCs.add(new Point(0,0));
		pntCs.add(new Point(-2,0));
		pntCs.add(new Point(-2,1));
		pntCs.add(new Point(-1,1));
		pntCs.add(new Point(-1,0));

		setCartesians(pntCs);
		setColor(Color.RED);
	}

	@Override
	public void move() {
		if (getExpiry() > 0) expire();

		//move right
		if (moveLeft) {
			getCenter().move(getCenter().x - speed, getCenter().y);
		} else {
			getCenter().move(getCenter().x + speed, getCenter().y);
		}



	}


}
