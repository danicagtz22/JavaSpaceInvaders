package edu.uchicago.gerber._03objects;

public class P8_1 {
    public static void main(String[] args)
    {
        //specification does not as to make this interactive

        Microwave myMicrowave = new Microwave(30, 2);
        myMicrowave.Start();
        myMicrowave.IncreaseThirty();
        myMicrowave.PowerSwitch();
        myMicrowave.Start();
        myMicrowave.Reset();
        myMicrowave.Start();
    }
}


class Microwave
{

    //Private variables
    private int time = 0;

    private int power = 0;

    public int getTime() {
        return time;
    }
    public int getPower() {return power;}


    //constructor
    public Microwave( int time, int power ) {
        this.time = time;
        this.power = power;

    }


    public void IncreaseThirty(){
        this.time+=30;
    }

    public void PowerSwitch(){

        if(this.power == 1){
            //switch power to 2
            this.power = 2;
        }else{
            this.power = 1;
        }
    }

    public void Reset(){
        this.power = 1;
        this.time = 0;
    }

    public void Start(){
        String seconds = Integer.toString(this.time);
        String microwavePower = Integer.toString(this.power);
        String concatString = "Cooking for " + seconds + " seconds" + " at level " + microwavePower;
        System.out.println(concatString);
    }

}