package edu.uchicago.gerber._08final.mvc.model;

import edu.uchicago.gerber._08final.mvc.controller.Game;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class AlienBonusShield extends Sprite {
    private boolean moveLeft = true;
    private int speed;


    public AlienBonusShield(int speed) {

        this.speed = speed;
        setOrientation(270);
        setRadius(25);
        setTeam(Team.FOE);
        setExpiry(300);
        setCenter(new Point(Game.DIM.width - 80, 50));

        //cartesian points which define the shape of the polygon
        List<Point> pntCs = new ArrayList<>();
        pntCs.add(new Point(0,9));
        pntCs.add(new Point(2,9));
        pntCs.add(new Point(2,7));
        pntCs.add(new Point(4,7));
        pntCs.add(new Point(4,5));
        pntCs.add(new Point(6,5));
        pntCs.add(new Point(6,3));
        pntCs.add(new Point(8,3));
        pntCs.add(new Point(8,0));

        pntCs.add(new Point(8,-2));
        pntCs.add(new Point(3,-2));
        pntCs.add(new Point(3,-4));
        pntCs.add(new Point(6,-4));
        pntCs.add(new Point(6,-6));
        pntCs.add(new Point(8,-6));
        pntCs.add(new Point(8,-8));
        pntCs.add(new Point(6, -8));
        pntCs.add(new Point(6, -6));
        pntCs.add(new Point(4, -6));
        pntCs.add(new Point(4,-8));
        pntCs.add(new Point(2, -8));
        pntCs.add(new Point(2,-6));
        pntCs.add(new Point(0, -6));

        //bottom left
        pntCs.add(new Point(0, -6));
        pntCs.add(new Point(-2,-6));
        pntCs.add(new Point(-2, -8));
        pntCs.add(new Point(-4,-8));
        pntCs.add(new Point(-4, -6));
        pntCs.add(new Point(-6, -6));
        pntCs.add(new Point(-6, -8));
        pntCs.add(new Point(-8,-8));
        pntCs.add(new Point(-8,-6));
        pntCs.add(new Point(-6,-6));
        pntCs.add(new Point(-6,-4));
        pntCs.add(new Point(-3,-4));
        pntCs.add(new Point(-3,-2));
        pntCs.add(new Point(-8,-2));
        pntCs.add(new Point(-8,0));


        //top left quadrant

        pntCs.add(new Point(-8,0));
        pntCs.add(new Point(-8,3));
        pntCs.add(new Point(-6,3));
        pntCs.add(new Point(-6,5));
        pntCs.add(new Point(-4,5));
        pntCs.add(new Point(-4,7));
        pntCs.add(new Point(-2,7));
        pntCs.add(new Point(-2,9));
        pntCs.add(new Point(0,9));



        pntCs.add(new Point(0,5));
        pntCs.add(new Point(-3,5));
        pntCs.add(new Point(-3,3));
        pntCs.add(new Point(-1,3));
        pntCs.add(new Point(-1,5));
        pntCs.add(new Point(0,5));
        pntCs.add(new Point(1,5));
        pntCs.add(new Point(3,5));
        pntCs.add(new Point(3,3));
        pntCs.add(new Point(1,3));
        pntCs.add(new Point(1,5));
        pntCs.add(new Point(0,5));
        pntCs.add(new Point(0,1));
        pntCs.add(new Point(2,1));
        pntCs.add(new Point(2,-1));
        pntCs.add(new Point(-2,-1));
        pntCs.add(new Point(-2,1));
        pntCs.add(new Point(0,1));



        setCartesians(pntCs);
        setColor(Color.BLUE);
    }

    @Override
    public void move() {

        if (getExpiry() > 0) expire();

        //move right
        if (moveLeft) {
            getCenter().move(getCenter().x - speed, getCenter().y);
        } else {
            getCenter().move(getCenter().x + speed, getCenter().y);
        }



    }


}