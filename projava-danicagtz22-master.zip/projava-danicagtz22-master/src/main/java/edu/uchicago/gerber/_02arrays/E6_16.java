package edu.uchicago.gerber._02arrays;
import java.util.Random;
import java.util.Scanner;


public class E6_16 {
    //some code referenced from https://explained.blog/programming/program-to-print-vertical-bar-chart/
    public static void main(String []args){

        Scanner scanner = new Scanner( System.in );
        System.out.print( "How many values will you be entering? " );
        int elements = scanner.nextInt();
        int[] elemValues = new int[ elements ];
        // add values to the array
        int currElem = 0;
        while( currElem < elements ) {
            int elemPlace = currElem + 1;
            System.out.printf( "Please enter element %d : ", elemPlace );
            elemValues[ currElem++ ] = scanner.nextInt();

        }

        createChart( elemValues );
    }


    private static void createChart( int[] elements ) {

        int rows = elements.length;
        int maxElemValue = maxVal( elements );

        int[] newValues = new int[rows];
        //get the number of asterisks per element according to proportion and add them to a new list
        for(int i=0;i<rows;i++) {
            int n = elements[i];
            int asterisks = (int) (20 * n / maxElemValue);
            newValues[i] = asterisks;
        }

        String[] horizontalRow = new String[ 20 + 1];


        for( int row = 0; row <= 20; row++ ) {

            String patternForThisRow = "";
            int barChartUnitAtThisRow = 20 - row;
            for( int column = 0; column < newValues.length; column++ ) {

                if( barChartUnitAtThisRow < newValues[ column ] ) {
                    patternForThisRow += " *  ";
                } else {
                    patternForThisRow += "  ";
                }
            }

            horizontalRow[ row ] = patternForThisRow;

        }

        for( String pattern : horizontalRow ) {
            System.out.println( pattern );
        }

        for( int value : elements )
            System.out.printf( " %d ", value );
    }

    private static int maxVal( int[] values ) {

        int max = 0;
        //if the max value is less than the current value we're on as we're iterating, then make that value the new max
        for( int value : values ) {
            if( max < value ) {
                max = value;
            }
        }

        return max;
    }


}


