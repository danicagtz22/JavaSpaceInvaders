package edu.uchicago.gerber._05dice;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class P10_19 {

    public static void main(String[] args) {
        RestaurantBillMaker billMaker = new RestaurantBillMaker();
        billMaker.setDefaultCloseOperation(EXIT_ON_CLOSE);
        billMaker.setSize(1000,1000);
        billMaker.setVisible(true);
    }
}
