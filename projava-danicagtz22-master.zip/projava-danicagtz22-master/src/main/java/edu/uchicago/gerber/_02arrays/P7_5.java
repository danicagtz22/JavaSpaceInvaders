package edu.uchicago.gerber._02arrays;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class P7_5 {
    public static void main(String[] args)
    {

        myCSVReader inputFile = new myCSVReader("/Users/Danica1/IdeaProjects/projava-danicagtz22/src/main/java/edu/uchicago/gerber/_02arrays/address.csv");

        System.out.println("Number of rows: " + inputFile.numberOfRows());

        System.out.print("Enter a row to get all its fields: ");
        Scanner console = new Scanner(System.in);
        String inp = console.next();
        int userInp = Integer.parseInt(inp);
        System.out.printf("Number of fields in row %d: %d " , userInp, inputFile.numberOfFields(userInp));
        System.out.println("\nEnter a row and column to get a specific field: ");
        String inp2 = console.next();
        int userInp2 = Integer.parseInt(inp2);
        String inp3 = console.next();
        int userInp3 = Integer.parseInt(inp3);
        System.out.printf("Row %d, Col %d: %s" ,userInp2, userInp3, inputFile.field(userInp2, userInp3));
    }
}


class myCSVReader
{
    static ArrayList<String > lines = new ArrayList<>();
    //we add each line inside our input file to a list of strings in order to process each line
    public myCSVReader(String inputFile)
    {
        String line = "";
        int i=0;
        // I use the Java's BufferedReader class for efficiency when reading the csv file. The File reader class is another way
        // to read a file apart from the Scanner class.
        try (BufferedReader br = new BufferedReader(new FileReader(inputFile)))
        {
            //While there are still lines in the file, we keep reading
            while ((line = br.readLine()) != null) {
                lines.add(i, line);
                i++;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public int numberOfRows()
    {
        // lines refers to the array list we have built with all the lines from the csv file. the size method
        //gives the number of "elements", lines in this case, in the array list
        return lines.size();
    }

    //This method gives the number of fields in a row  as separated by commas but ignoring those inside double quotes
    public int numberOfFields(int row)
    {
        //from our list of lines, get the index of the desired row and split all the fields using commas.
        //Using regex allows us to ignore those commas inside the field itself
        String[] fields = lines.get(row-1).split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
        return fields.length;
    }

    //This method returns the field value at a given row and column
    public String field(int row, int column)
    {
        //similar to the numberOfFields method, we select the desired row's index and from there we select the column, arriving the desired field
        String[] fields = lines.get(row-1).split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
        return fields[column-1];
    }
}