package edu.uchicago.gerber._02arrays;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class E7_4 {
    public static void main(String[] args) throws FileNotFoundException {

        //prompt the user for a file name to read and one to write to
        Scanner console = new Scanner(System.in);
        System.out.print("Input file: ");
        String inputFileName = console.next();
        System.out.print("Output file: ");
        String outputFilename = console.next();

            File file = new File(inputFileName);
            Scanner in = new Scanner(file);


            // create a PrintWriter object for writing to a new file
            PrintWriter out = new PrintWriter(outputFilename);

            //inputfile  /Users/Danica1/IdeaProjects/projava-danicagtz22/src/main/java/edu/uchicago/gerber/_02arrays/mar.txt

            //outputfile  /Users/Danica1/IdeaProjects/projava-danicagtz22/src/main/java/edu/uchicago/gerber/_02arrays/outputFile.txt
            // read each line from file and print it
            System.out.println("Reading File Using Scanner:");
            int lineNumber = 1;
            while(in.hasNextLine()) {
                out.printf("/* %d */ %s\n", lineNumber, in.nextLine());
                lineNumber ++;
            }
            System.out.println("Done!");
            // close Scanner and PrintWriter objects
            out.close();
            in.close();
    }
}
//Write a program that reads a file containing text. Read each line and send it to the output file, preceded by line numbers
//prompt the user for input and output file names
