package edu.uchicago.gerber._02arrays;
import java.util.Scanner;


public class P5_24 {

    public static void main(String []args){

        // Use Scanner for getting user input
        Scanner in = new Scanner(System.in);

        String inp = in.nextLine();
        System.out.println("You entered  " + inp);
        int result = decimalNumber(inp);
        System.out.println("This is equal to " + result);



    }

    //this method converts a RomanNumeral string into an int
    public static int decimalNumber (String inp){
        int total = 0;
        //while string is not empty
        for (int i=0; i<inp.length(); i++){
            {
                // if str has length 1, or char1 > char 2, add the value to total. Else, add the difference to between char1 and char 2 to the total
                if (i+1 == inp.length() || numeralToInt(inp.charAt(i)) >= numeralToInt(inp.charAt(i + 1))) {
                    total += numeralToInt(inp.charAt(i));
                } else {
                    total -= numeralToInt(inp.charAt(i));
                }
            }
        }
        return total;
    }

    //this method translates each numeral to a decimal number
    public static int numeralToInt (char numeral){
        int i;
        if (numeral == 'M') {
            return i = 1000;
        } else if (numeral == 'D') {
            return i = 500;
        } else if (numeral == 'C') {
            return i = 100;
        } else if (numeral == 'L') {
            return i = 50;
        } else if (numeral == 'X'){
            return i = 10;
        } else if (numeral == 'V'){
            return i = 5;
        } else if (numeral == 'I'){
            return i = 1;
        }
        return i = 0;
    }

}


