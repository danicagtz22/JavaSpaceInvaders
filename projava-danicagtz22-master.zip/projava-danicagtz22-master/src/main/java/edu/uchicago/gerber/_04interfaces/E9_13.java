package edu.uchicago.gerber._04interfaces;
import java.awt.*;
import java.util.Scanner;

public class E9_13{


    public static void main(String[] args)
    {


        //take input from user
        Scanner scanIn = new Scanner(System.in);


            //get location coordinates first
            System.out.print("Enter x coordinate: ");
            int x = scanIn.nextInt();

            System.out.print("Enter y coordinate: ");
            int y = scanIn.nextInt();


            // get the dimensions
            System.out.print("Enter the width: ");
            int width = scanIn.nextInt();

            System.out.print("Enter the height: ");
            int height = scanIn.nextInt();

            //create a new instance of the BetterRectangle class
            BetterRectangle betterRectangle = new BetterRectangle(x, y, width, height);


            System.out.println("\nThe Rectangle specifications are these:  ");

            //show location of rectangle
            System.out.println("Rectangle is located at location: (" + x + ", " + y + ")");

            //show user the dimensions they provided
            System.out.println("The rectangle's width = " + width + " and height = " + height);

            //call the perimeter method
            System.out.println("The rectangle's perimeter is : " + betterRectangle.getPerimeter());

            //call the area method
            System.out.println("The rectangle's area is : " + betterRectangle.getArea());

            //input code references this driver code https://www.chegg.com/homework-help/questions-and-answers/javaawtrectangle-class-standard-java-library-supply-method-compute-area-perimeter-rectangl-q4550466

    }
}


class BetterRectangle extends Rectangle {


    //default constructor
    public BetterRectangle(){
        super.setLocation(0,0);
        super.setSize(10,10);

    }



    //overload the constructor to set different parameters
    public BetterRectangle(int x, int y, int width, int height){
       super.setLocation(x, y);
       super.setSize(width, height);

    }

   public double getPerimeter(){

        double perimeter = (this.getHeight() + this.getWidth()) * 2;

        return perimeter;
   }

   public double getArea(){
        double area = this.getHeight()* this.getWidth();

        return area;
    }
}