package edu.uchicago.gerber._06design.E0_4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

//this is just an example Driver inside an example package
public class E12_4 {

    public static void main(String[] args) {

        System.out.println("Let's learn arithmetic");
        player player1 = new player();
        String keepGoing;
        do {
            if (player1.getLevel() == 1) {
                levels level1 = new levels();
                do {
                    int answer = level1.generateLevel1Problem();
                    int result = new Scanner(System.in).nextInt();

                    int tries = 0;
                    if (result == answer) {
                        System.out.println("Correct!");
                        player1.setPlayerScore(1);
                    } else {
                        System.out.println("Wrong answer");
                        tries += 1;
                        System.out.println("Try again");
                        int resultChance2 = new Scanner(System.in).nextInt();
                        if (resultChance2 == answer) {
                            System.out.println("Correct!");
                            player1.setPlayerScore(1);
                        } else {
                            System.out.println("Incorrect, let's move on");
                        }

                    }

                    if (player1.getPlayerScore() == 5) {
                        player1.setLevel(2);
                    }

                } while (player1.getPlayerScore() < 5);
            } else if (player1.getLevel() == 2) {
                levels level2 = new levels();
                do {
                    int answer = level2.generateLevel2Problem();
                    int result = new Scanner(System.in).nextInt();

                    int tries = 0;
                    if (result == answer) {
                        System.out.println("Correct!");
                        player1.setPlayerScore(1);
                    } else {
                        System.out.println("Wrong answer");
                        tries += 1;
                        System.out.println("Try again");
                        int resultChance2 = new Scanner(System.in).nextInt();
                        if (resultChance2 == answer) {
                            System.out.println("Correct!");
                            player1.setPlayerScore(1);
                        } else {
                            System.out.println("Incorrect, let's move on");
                        }

                    }

                    if (player1.getPlayerScore() == 10) {
                        player1.setLevel(3);
                    }

                } while (player1.getPlayerScore() < 10);
            } else {
                player1.setLevel(3);


                levels level3 = new levels();
                do {
                    int answer = level3.generateLevel3Problem();

                    int result = new Scanner(System.in).nextInt();

                    int tries = 0;
                    if (result == answer) {
                        System.out.println("Correct!");
                        player1.setPlayerScore(1);
                    } else {
                        System.out.println("Wrong answer");
                        tries += 1;
                        System.out.println("Try again");
                        int resultChance2 = new Scanner(System.in).nextInt();
                        if (resultChance2 == answer) {
                            System.out.println("Correct!");
                            player1.setPlayerScore(1);
                        } else {
                            System.out.println("Incorrect, let's move on");
                        }

                    }

                    if (player1.getPlayerScore() == 15) {
                        System.out.println("Congrats, you've completed all levels!");

                    }

                } while (player1.getPlayerScore() < 15);
            }
            System.out.println("\nDo you want to continue learning?[y/n]");
            keepGoing = new Scanner(System.in).nextLine();

        } while (keepGoing.equals("y"));
        System.out.println("see you later!");
    }
}

