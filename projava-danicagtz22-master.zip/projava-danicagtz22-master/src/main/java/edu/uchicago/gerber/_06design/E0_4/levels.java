package edu.uchicago.gerber._06design.E0_4;

import java.util.Random;

public class levels {


    public int generateLevel1Problem(){
        int firstNum = new Random().nextInt(5)+1;
        int secondNumber;
        do {
            secondNumber = new Random().nextInt(5)+1;
        }while (firstNum+secondNumber>=10);

        System.out.print(String.format("%d+%d=", firstNum ,secondNumber));

        int answer = firstNum + secondNumber;

        return answer;
    }

    public int generateLevel2Problem(){
        int firstNum = new Random().nextInt(10)+1;
        int secondNumber = new Random().nextInt(10)+1;

        System.out.print(String.format("%d+%d=", firstNum ,secondNumber));

        int answer = firstNum + secondNumber;

        return answer;
    }

    public int generateLevel3Problem(){
        int firstNum = new Random().nextInt(10)+1;
        int secondNumber;
        do {
            secondNumber = new Random().nextInt(5)+1;
        } while (firstNum < secondNumber);


        System.out.print(String.format("%d - %d=", firstNum ,secondNumber));

        int answer = firstNum - secondNumber;

        return answer;
    }
}
