## All homework assignments base-code for Java Programming UChicago MPCS 51036

This project contains all the base code you will need for your homework (called projects) in Java Programming 51036 -- but not the answers :(
There are also some simple examples in this project. Each package (e.g. _01control) contains a file called _instructions.txt which contains instructions for each project.

## the master branch

The master branch is the branch that your graders will grade. No other branch will be graded.
You may develop _08final (the video game) in kotlin. I have translated the java source to kotlin for the
game only. To develop in kotlin, do the following:
1/ stay on the master branch and delete the mvc directory completely.
2/ commit the deletion of the mvc with this command $git commit -m "deleted mvc dir"
3/ issue this command $git merge kotlin

## Access

You will fork this project and then push to it as you complete your assignments.
You may create however many branches you like, but be sure to merge those changes back to master as master is the only branch that the graders will evaluate.

If you don't know how to merge, stay on master...or ask me during office hours and I will show you how to merge.



