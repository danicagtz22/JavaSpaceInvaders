package edu.uchicago.gerber._04interfaces;


import java.util.Scanner;

public class E9_8 {


    public static void main(String[] args)
    {

        BasicAccount basicAccount = new BasicAccount();

        Scanner in  = new Scanner(System.in);
        boolean done = false;
        while(!done){
            System.out.print("D)eposit  W)ithdraw  Q)uit: ");
            String input = in.next();
            if (input.equals("D") || input.equals("W")) {
                //Deposit or Withdraw
                System.out.print("Enter amount: ");
                double amount = in.nextDouble();

                if (input.equals("D")) { basicAccount.deposit(amount); }
                else {basicAccount.withdraw(amount); }

                System.out.println("Balance: " + basicAccount.getBalance());
            }else if (input.equals("Q")){
                done = true;
            }
        }



    }
}
//Implement a subclass of BankAccount called Basic Account whose withdraw method will not withdraw more money
// than it's currently in the account

class BankAccount{

    private double balance;

    public BankAccount(){
        balance = 0;
    }


    public void deposit(double amount){
        balance = balance + amount;
    }

    public void withdraw(double amount){
        balance = balance - amount;
    }

    public void monthEnd(double amount){

    }

    public double getBalance(){
        return balance;
    }


}
class BasicAccount extends BankAccount{

    public BasicAccount(){

    }
    public void withdraw(double amount){

       double balance = getBalance();
       if (balance < amount){
           //cannot withdraw more than the current balance is
           super.withdraw(balance);
       }else{
           //just withdraw smaller amount
           super.withdraw(amount);
       }
    }
}