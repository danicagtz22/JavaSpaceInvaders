package edu.uchicago.gerber._08final.mvc.model;

import edu.uchicago.gerber._08final.mvc.controller.Game;

import java.awt.*;

public class FalconDeath extends MoveAdapter {


    private int mExpiry;

    private Point mCenter;

    private int mRadius;

    private double deltaX, deltaY;

    public FalconDeath( Bomb bomb){
        mCenter = bomb.getCenter();
        mRadius = 80;
        mExpiry = 4;
        deltaX = bomb.getDeltaX();
        deltaY = bomb.getDeltaY();
    }

    public Point getCenter() {
        return mCenter;
    }

    public void setCenter(Point mCenter) {
        this.mCenter = mCenter;
    }

    @Override
    public void draw(Graphics g){
        super.draw(g);

        Color color = new Color(Game.R.nextInt(256), Game.R.nextInt(256), Game.R.nextInt(256));
        g.setColor(color);
        g.fillOval(mCenter.x - mRadius / 2, mCenter.y - mRadius /2 ,mRadius, mRadius);
    }

    @Override
    public void move(){

        Point center = getCenter();

        //right-bounds reached
        if (center.x > Game.DIM.width) {
            setCenter(new Point(1, center.y));
            //left-bounds reached
        } else if (center.x < 0) {
            setCenter(new Point(Game.DIM.width - 1, center.y));
            //bottom-bounds reached
        } else if (center.y > Game.DIM.height) {
            setCenter(new Point(center.x, 1));
            //top-bounds reached
        } else if (center.y < 0) {
            setCenter(new Point(center.x, Game.DIM.height - 1));
            //in-bounds
        } else {
            double newXPos = center.x + deltaX/2;
            double newYPos = center.y + deltaY/2;
            setCenter(new Point((int) newXPos, (int) newYPos));
        }


        if(mExpiry > 0 ){
            mRadius += 10;
            mExpiry --;
        }else{
            CommandCenter.getInstance().getOpsQueue().enqueue(this, GameOp.Action.REMOVE);
        }
    }

    @Override
    public Team getTeam() {
        return Team.DEBRIS;
    }
}