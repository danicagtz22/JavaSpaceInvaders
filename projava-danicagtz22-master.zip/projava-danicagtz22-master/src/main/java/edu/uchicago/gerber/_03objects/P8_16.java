package edu.uchicago.gerber._03objects;

import java.util.ArrayList;
import java.util.List;

public class P8_16 {
    public static void main(String[] args)
    {
        //specification does not as to make this interactive

        Message myMessage = new Message("julie", "tom");
        myMessage.append("hi, Jules! send me the supporting docs for the last report");
        myMessage.toString();
        System.out.println(myMessage.toString());

        Message myMessage2 = new Message("rose", "jack");
        myMessage2.append("hi, rose");
        myMessage2.toString();
        System.out.println(myMessage2.toString());

        Message myMessage3 = new Message("jenny", "forrest");
        myMessage3.append("Greensboro, AL ");
        myMessage3.toString();
        System.out.println(myMessage3.toString());

        Mailbox myInbox = new Mailbox();
        myInbox.addMessage(myMessage);
        myInbox.addMessage(myMessage2);
        myInbox.addMessage(myMessage3);

        Message message = myInbox.getMessage(2);
        System.out.println(message.toString());

    }
}
class Mailbox{

    private List<Message> inbox = new ArrayList<Message>();


    public Mailbox(){

    }

    public void addMessage(Message m){
       List<Message> inbox =  this.inbox;
       inbox.add(m);
       this.inbox = inbox;

    }

    public Message getMessage(int i){
        List<Message> inbox = this.inbox;
        return  inbox.get(i);
    }

    public void removeMessage(int i){
        List<Message> inbox = this.inbox;
        inbox.remove(i);
        this.inbox = inbox;
    }

}

class Message
{

    //Private variables
    private String recipient;

    private String sender;

    private String message = "";



    public String getRecipient(){
        return this.recipient;
    }
    public String getSender(){
        return this.sender;
    }
    public String getMessage(){
        return this.message;
    }


    //constructor
    public Message( String recipient, String sender ) {
        this.recipient = recipient;
        this.sender = sender;

    }

    public void append(String m){
        this.message = this.message + m;
    }

    public String toString(){
        String email = "From: " + sender + "\nTo: " + recipient + "\nMessage:  " + message;
        return email;
    }

}