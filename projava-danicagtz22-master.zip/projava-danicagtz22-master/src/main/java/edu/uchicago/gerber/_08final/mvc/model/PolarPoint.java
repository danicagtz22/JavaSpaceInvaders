package edu.uchicago.gerber._08final.mvc.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PolarPoint {
    private Double r; // corresponds to the hypotenuse in cartesean, number between 0 and 1
    private Double theta; //degrees in radians, number between 0 and 6.283
}
