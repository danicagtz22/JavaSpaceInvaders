package edu.uchicago.gerber._02arrays;
import java.util.Scanner;


public class P5_8 {

    public static void main(String []args){

        // Use Scanner object to get user input
        Scanner in = new Scanner(System.in);

        String inp = in.nextLine();
        System.out.println("You entered  " + inp);

        int i;
        try {
            i = Integer.parseInt(inp);
            boolean isLeap = isLeapYear(i);
            if (isLeap){
                System.out.println("That's a leap year!");
            } else{
                System.out.println("That's NOT a leap year!" );
            }
        }
        catch (NumberFormatException e) {
            i = 0;
        }


    }
    //this program tests whether a year is a leap year - a year with 366 days
    public static boolean isLeapYear(int year){

        if (year % 4 != 0) {
            return false;
        } else if (year % 400 == 0) {
            return true;
        } else if (year % 100 == 0) {
            return false;
        } else {
            return true;
        }
    }

}


