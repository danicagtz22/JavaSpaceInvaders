## Space Invaders Revamped

This game is based off the popular arcade game Space Invaders.

The goal is to exterminate all the green aliens before they land 
and the invasion begins. 

There are three main boulders at the beginning where the falcon ship can take cover. 

Each of these boulders can only take a max of three alien hits before it is destroyed.

When the boulder has been compromised it changes color to alert the player. 

You move up levels when there are no more aliens to destroy and the level of difficulty increases as the aliens 
move down faster. 

The blue alien gives you an additional boulder shield that moves with the ship to the next level as long as it isn't destroyed.

The red alien is worth 10 points whereas the green aliens are worth 1 point each. 






